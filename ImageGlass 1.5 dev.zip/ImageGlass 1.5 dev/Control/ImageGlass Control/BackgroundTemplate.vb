﻿'ImageGlass Project - Image viewer for Windows
'Copyright (C) 2012 DUONG DIEU PHAP
'Project homepage: http://imageglass.codeplex.com

'This program is free software: you can redistribute it and/or modify
'it under the terms of the GNU General Public License as published by
'the Free Software Foundation, either version 3 of the License, or
'(at your option) any later version.

'This program is distributed in the hope that it will be useful,
'but WITHOUT ANY WARRANTY; without even the implied warranty of
'MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
'GNU General Public License for more details.

'You should have received a copy of the GNU General Public License
'along with this program.  If not, see <http://www.gnu.org/licenses/>.

Public Class BackgroundTemplate

    Private m_cBackGroundH As Color = Color.FromArgb(100, 179, 206, 236) 'màu ngang
    Private m_cBackGroundV As Color = Color.FromArgb(100, 179, 206, 236) 'màu dọc
    Private m_BackgroundH_Width As Integer = 1 'độ dày của dãy màu ngang
    Private m_BackgroundV_Width As Integer = 1 'độ dày của dãy màu dọc
    Private m_Distance_Width As Integer = 10 'khoảng cách giữa 2 dãy màu

    Public Property HorizontalColor() As Color
        Get
            Return m_cBackGroundH
        End Get
        Set(ByVal value As Color)
            m_cBackGroundH = value
        End Set
    End Property

    Public Property VerticalColor() As Color
        Get
            Return m_cBackGroundV
        End Get
        Set(ByVal value As Color)
            m_cBackGroundV = value
        End Set
    End Property

    Public Property HorizontalWidth() As Integer
        Get
            Return m_BackgroundH_Width
        End Get
        Set(ByVal value As Integer)
            m_BackgroundH_Width = value
        End Set
    End Property

    Public Property VerticalWidth() As Integer
        Get
            Return m_BackgroundV_Width
        End Get
        Set(ByVal value As Integer)
            m_BackgroundV_Width = value
        End Set
    End Property

    Public Property DistanceWidth() As Integer
        Get
            Return m_Distance_Width
        End Get
        Set(ByVal value As Integer)
            m_Distance_Width = value
        End Set
    End Property


End Class
