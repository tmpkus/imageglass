﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ThumbBar
{
    public class ThumbnailItemClickEventArgs : EventArgs
    {

        public ThumbnailItemClickEventArgs(int Itemindex)
        {
            _selectedIndex = Itemindex;
        }


        private int _selectedIndex;

        /// <summary>
        /// Get index seleted items
        /// </summary>
        public int SeletedIndex
        {
            get
            {
                return _selectedIndex;
            }
        }


    }
}
