﻿/*
ImageGlass Project - Image viewer for Windows
Copyright (C) 2012 DUONG DIEU PHAP
Project homepage: http://imageglass.codeplex.com

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace ImageGlass.ThumbBar
{
    /// <summary>
    /// Delegate quản lý sự kiện click chuột lên ThumbnailItem
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    public delegate void ClickEventHander(object sender, EventArgs e);

    public partial class ThumbItem : UserControl
    {

        #region Event Click
        /// <summary>
        /// Event click chuột lên ThumbnailItem
        /// </summary>
        public event ClickEventHander ClickItem;

        /// <summary>
        /// Phát sinh sự kiện click
        /// </summary>
        /// <param name="e"></param>
        protected virtual void OnClickItem(EventArgs e)
        {
            if (ClickItem != null)
                ClickItem(this, e);
        }
        #endregion

        private void ThumbItem_Click(object sender, EventArgs e)
        {
            //Phát sinh sự kiện ClickItem trong sự kiện Click
            OnClickItem(EventArgs.Empty);

            if (_selectedOnClick)
            {
                this._isSelected = true;
            }
        }



        public ThumbItem()
        {
            InitializeComponent();

            _imagePath = string.Empty;//duong dan hinh anh
            _image = null;//hinh anh thumbnail  

            _ColorNormal = Color.FromArgb(50, 0, 0, 0);
            _ColorHover = Color.FromArgb(30, 0, 0, 0);
            _ColorDown = Color.FromArgb(0, 0, 0, 0);
            _ColorSelected = Color.FromArgb(100, 255, 255, 255);

            _isSelected = false;
            _thumbLocation = new Point(0, 0);

            _isNormal = true;
            _isDown = false;
            _selectedOnClick = true;
            _isUp = false;
        }

        private string _imagePath = string.Empty;//duong dan hinh anh
        private Image _image;//hinh anh thumbnail

        private Color _ColorNormal;
        private Color _ColorHover;
        private Color _ColorDown;
        private Color _ColorSelected;
        private bool _isSelected;

        private Point _thumbLocation;
        private bool _isNormal;
        private bool _isDown;
        private bool _selectedOnClick;
        private bool _isUp;
        
        

        #region Properties

        /// <summary>
        /// Get thumbnail path
        /// </summary>
        public string ImagePath
        {
            get { return _imagePath; }
            set
            {
                if (File.Exists(value))
                {
                    _imagePath = value;
                    ThumbnailCreation tb = new ThumbnailCreation();
                    tb.MaxImageLength = 90;
                    _isNormal = true;

                    try
                    {
                        _image = tb.CreateThumbnailImage(_imagePath,
                                                        ScalingOptions.MaintainAspect,
                                                        new Size(90, 90));
                        this.Width = _image.Width;
                    }
                    catch
                    {
                        _image = null;
                        _imagePath = string.Empty;
                    }
                    
                    
                    this.Invalidate();
                }
                else
                {
                    _image = null;
                    _imagePath = string.Empty;
                    this.Invalidate();
                }
            }
        }

        /// <summary>
        /// Get thumbnail image
        /// </summary>
        public Image Image
        {
            get { return _image; }
        }

        /// <summary>
        /// Get or Set default background color
        /// </summary>
        public Color ColorNormal
        {
            get { return _ColorNormal; }
            set
            {
                _ColorNormal = value;
                this.Invalidate();

                Graphics g = this.CreateGraphics();
                DrawThumbItemColor(g, _ColorNormal);
            }
        }

        /// <summary>
        /// Get or set hover color
        /// </summary>
        public Color ColorHover
        {
            get { return _ColorHover; }
            set
            {
                _ColorHover = value;                
            }
        }

        /// <summary>
        /// Get or Set mousedown Color
        /// </summary>
        public Color ColorDown
        {
            get { return _ColorDown; }
            set
            {
                _ColorDown = value;
                this.Invalidate();
            }
        }

        /// <summary>
        /// Get or Set Selected color
        /// </summary>
        public Color ColorSelected
        {
            get { return _ColorSelected; }
            set
            {
                _ColorSelected = value;
                this.Invalidate();

                Graphics g = this.CreateGraphics();
                DrawSelectedItem(g, _ColorSelected);
            }
        }

        /// <summary>
        /// Get or Set selected state
        /// </summary>
        public bool IsSelected
        {
            get
            {
                return _isSelected;
            }
            set
            {
                _isSelected = value;
                this.Invalidate();
            }
        }

        /// <summary>
        /// Get location of thumbnail
        /// </summary>
        public Point ThumbLocation
        {
            get { return _thumbLocation; }
        }

        /// <summary>
        /// Get or Set type of click
        /// </summary>
        public bool SelectedOnClick
        {
            get { return _selectedOnClick; }
            set
            {
                _selectedOnClick = value;

            }
        }
      
        #endregion

        /// <summary>
        /// Draw thumbnail 
        /// </summary>
        /// <param name="g"></param>
        private void DrawThumbnail(Graphics g)
        {
            if (_image != null)
            {
                int x, y;
                x = 0; y = 0;

                if (_image.Width < this.Width)
                {
                    x = this.Width / 2 - _image.Width / 2;
                }
                if (_image.Height < this.Height)
                {
                    y = this.Height / 2 - _image.Height / 2;
                }

                _thumbLocation = new Point(x, y);
                g.DrawImage(_image, _thumbLocation);
            }
        }
             

        protected override void OnPaint(PaintEventArgs e)
        {
            e.Graphics.Clear(this.BackColor);//clear background
            DrawThumbnail(e.Graphics); //load thumbnail

            if (_isSelected)
            {
                DrawSelectedItem(e.Graphics, _ColorSelected);
            }
            if (_isDown)
            {
                DrawThumbItemColor(e.Graphics, _ColorDown);
            }
            else if (_isNormal)
            {
                DrawThumbItemColor(e.Graphics, _ColorNormal);
            }

            base.OnPaint(e);
        }

        /// <summary>
        /// Draw thumnail color
        /// </summary>
        /// <param name="g"></param>
        /// <param name="c"></param>
        private void DrawThumbItemColor(Graphics g, Color c)
        {
            if (_image != null)
            {
                SolidBrush b = new SolidBrush(c);

                g.FillRectangle(b, new Rectangle(_thumbLocation.X, _thumbLocation.Y, 
                                                _image.Width, _image.Height));
            }
        }

        /// <summary>
        /// Draw selected thumbanil item
        /// </summary>
        /// <param name="g"></param>
        /// <param name="c"></param>
        private void DrawSelectedItem(Graphics g, Color c)
        {
            if (_image != null && _isSelected == true)
            {
                Pen p = new Pen(c);
                p.Width = 7;
                
                g.DrawRectangle(p, _thumbLocation.X + 3, _thumbLocation.Y + 3,
                                    _image.Width - 7, _image.Height - 7);                

            }
        }

        private void ThumbItem_MouseEnter(object sender, EventArgs e)
        {
            Graphics g = this.CreateGraphics();
            _isNormal = true;
            _isDown = false;
            _isUp = false;
            //this.Invalidate();
            g.Clear(this.BackColor);
            DrawThumbnail(g);
            DrawThumbItemColor(g, _ColorHover);
            DrawSelectedItem(g, _ColorSelected);
        }

        private void ThumbItem_MouseLeave(object sender, EventArgs e)
        {
            //Graphics g = this.CreateGraphics();
            _isNormal = true;
            _isDown = false;
            if (!_isUp)
            {
                _isUp = false;
                this.Invalidate();
            }
            //DrawThumbItemColor(g, _ColorNormal);
        }

        private void ThumbItem_MouseDown(object sender, MouseEventArgs e)
        {
            //Graphics g = this.CreateGraphics();
            _isNormal = false;
            _isDown = true;
            _isUp = false;
            this.Invalidate();
            //DrawThumbItemColor(g, _ColorSelected);
        }

        private void ThumbItem_MouseUp(object sender, MouseEventArgs e)
        {
            _isUp = true;
            ThumbItem_MouseEnter(null, null);
        }

        

        


    }
}
