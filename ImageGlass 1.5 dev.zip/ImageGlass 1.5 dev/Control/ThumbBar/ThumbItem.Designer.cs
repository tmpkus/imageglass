﻿namespace ImageGlass.ThumbBar
{
    partial class ThumbItem
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // ThumbItem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(245)))), ((int)(((byte)(251)))));
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MaximumSize = new System.Drawing.Size(90, 90);
            this.MinimumSize = new System.Drawing.Size(20, 90);
            this.Name = "ThumbItem";
            this.Size = new System.Drawing.Size(90, 90);
            this.Click += new System.EventHandler(this.ThumbItem_Click);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.ThumbItem_MouseDown);
            this.MouseEnter += new System.EventHandler(this.ThumbItem_MouseEnter);
            this.MouseLeave += new System.EventHandler(this.ThumbItem_MouseLeave);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.ThumbItem_MouseUp);
            this.ResumeLayout(false);

        }

        #endregion
    }
}
