﻿/*
ImageGlass Project - Image viewer for Windows
Copyright (C) 2012 DUONG DIEU PHAP
Project homepage: http://imageglass.codeplex.com

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Threading;

namespace ImageGlass.ThumbBar
{
    public partial class ThumbBar : UserControl
    {

        public ThumbBar()
        {
            InitializeComponent();

            _items = new List<ThumbItem>();
            _selectedIndex = -1;
            _isShowTooltip = true;

            _ColorNormal = Color.FromArgb(50, 0, 0, 0);
            _ColorHover = Color.FromArgb(30, 0, 0, 0);
            _ColorDown = Color.FromArgb(0, 0, 0, 0);
            _ColorSelected = Color.FromArgb(100, 255, 255, 255);

            _isLoadFileComplete = false;

        }

        //Thumbnail location: 5, 6
        //Height: 115

        private List<ThumbItem> _items = new List<ThumbItem>();
        private int _selectedIndex = -1;
        private bool _isShowTooltip = true;
        private Thread _t;
        private string _thumbPath;
        private ClickEventHander delegateClickEventHander;

        private Color _ColorNormal;
        private Color _ColorHover;
        private Color _ColorDown;
        private Color _ColorSelected;

        private bool _isLoadFileComplete;
        private int _loadedIndex = 0;

        List<ThumbItem> dsItemToAdd = new List<ThumbItem>();
        
        #region Properties
        /// <summary>
        /// Get Value if loading file complete
        /// </summary>
        public bool IsLoadFileComplete
        {
            get { return _isLoadFileComplete; }
        }

        /// <summary>
        /// Get or Set setected item
        /// </summary>
        public int SelectedIndex
        {
            get
            {
                for (int i = 0; i < _items.Count; i++)
                {
                    if (_items[i].IsSelected)
                    {
                        _selectedIndex = i;
                        return _selectedIndex;
                    }
                }
                return -1;
            }
            set
            {
                //neu selected Index > -1 va co item
                if (value > -1 && _items.Count > 0 && value < _items.Count)
                {
                    _selectedIndex = value;

                    for (int i = 0; i < _items.Count; i++)
                    {
                        _items[i].IsSelected = false;
                    }

                    _items[_selectedIndex].IsSelected = true;
                    this.ScrollControlIntoView(_items[_selectedIndex]);
                }

                
            }
        }

        /// <summary>
        /// Get Thumbnail items
        /// </summary>
        public List<ThumbItem> Items
        {
            get { return _items; }
        }

        /// <summary>
        /// Get os Set tooltip visibility
        /// </summary>
        public bool IsShowTooltip
        {
            get { return _isShowTooltip; }
            set
            {
                _isShowTooltip = value;

                if (value)
                {
                    for (int i = 0; i < _items.Count; i++)
                    {
                        tip.SetToolTip(_items[i], _items[i].ImagePath);
                    }
                }
                else
                {
                    tip.RemoveAll();
                }
            }
        }

        /// <summary>
        /// Get or Set BackColor
        /// </summary>
        public override Color BackColor
        {
            get
            {
                return base.BackColor;
            }
            set
            {
                if (_items.Count > 0)
                {
                    for (int i = 0; i < _items.Count; i++)
                    {
                        _items[i].BackColor = value;
                    }
                }
                base.BackColor = value;

            }
        }

        /// <summary>
        /// Get or Set default background color
        /// </summary>
        public Color ColorNormal
        {
            get { return _ColorNormal; }
            set
            {
                _ColorNormal = value;
                for (int i = 0; i < _items.Count; i++)
                {
                    _items[i].ColorNormal = value;
                }
            }
        }

        /// <summary>
        /// Get or set hover color
        /// </summary>
        public Color ColorHover
        {
            get { return _ColorHover; }
            set
            {
                _ColorHover = value;
                for (int i = 0; i < _items.Count; i++)
                {
                    _items[i].ColorHover = value;
                }
            }
        }

        /// <summary>
        /// Get or Set mousedown Color
        /// </summary>
        public Color ColorDown
        {
            get { return _ColorDown; }
            set
            {
                _ColorDown = value;
                for (int i = 0; i < _items.Count; i++)
                {
                    _items[i].ColorDown = value;
                }
            }
        }

        /// <summary>
        /// Get or Set Selected color
        /// </summary>
        public Color ColorSelected
        {
            get { return _ColorSelected; }
            set
            {
                _ColorSelected = value;
                for (int i = 0; i < _items.Count; i++)
                {
                    _items[i].ColorSelected = value;
                }
            }
        }
        #endregion

        #region Phat sinh su kien
        public event EventHandler AddItemsCompletedEventHandeler;
        /// <summary>
        /// Bắt sự kiện thêm file thành công
        /// </summary>
        /// <param name="e"></param>
        public void OnAddItemsCompletedEventHandler(EventArgs e)
        {
            if (AddItemsCompletedEventHandeler != null)
            {
                AddItemsCompletedEventHandeler(this, EventArgs.Empty);
            }
        }
        #endregion


        #region Cac ham xu ly
        /// <summary>
        /// Add new thumbnail to ThumbnailBar
        /// </summary>
        /// <param name="ti">Thumbnail item</param>
        /// <returns>Index of new item</returns>
        public int AddItems(ThumbItem ti)
        {
            _items.Add(ti);
            return _items.Count - 1;
        }

        /// <summary>
        /// Add items
        /// </summary>
        /// <param name="ds">List of thumbnail item</param>
        /// <param name="hdlClickItem">Event Click of Thumbnail Item</param>
        public void AddItems(List<ThumbItem> ds, ClickEventHander hdlClickItem)
        {
            dsItemToAdd = ds;
            delegateClickEventHander = hdlClickItem;

            ThreadStart s = new ThreadStart(AddItemsList);
            _t = new Thread(s);
            _t.IsBackground = true;
            _t.Start();

            _isLoadFileComplete = false;
            timRefreshFile.Enabled = true;
        }

        private void AddItemsList()
        {
            for (int i = 0; i < dsItemToAdd.Count; i++)
            {
                dsItemToAdd[i].ClickItem += delegateClickEventHander;
                _items.Add(dsItemToAdd[i]);
            }
            _isLoadFileComplete = true;
        }

        /// <summary>
        /// Add new thumbnail to ThumbnailBar
        /// </summary>
        /// <param name="imgPath">Image path</param>
        /// <returns>Index of new items</returns>
        public int AddItems(string imgPath)
        {
            ThumbItem ti = new ThumbItem();
            ti.ImagePath = imgPath;            
            _items.Add(ti);
            
            return _items.Count - 1;
        }

        /// <summary>
        /// Add thumbnail from dir
        /// </summary>
        /// <param name="dir"></param>
        public void AddItemsFromDir(string dir, ClickEventHander hdlClickItem)
        {
            if (!Directory.Exists(dir)) return;
            _thumbPath = dir;
            delegateClickEventHander = hdlClickItem;

            ThreadStart s = new ThreadStart(AddItemsFromDir);
            _t = new Thread(s);
            _t.IsBackground = true;
            _t.Start();

            _isLoadFileComplete = false;
            timRefreshFile.Enabled = true;
        }

        private void AddItemsFromDir()
        {
            foreach (string d in Directory.GetFiles(_thumbPath))
            {
                ThumbItem ti = new ThumbItem();
                ti.ImagePath = d;

                if (ti.ImagePath.Length != 0)//neu anh hop le
                {
                    ti.ClickItem += delegateClickEventHander;                    
                    _items.Add(ti);                    
                }
            }

            _isLoadFileComplete = true;
        }

        

        /// <summary>
        /// Remove a thumbnail item
        /// </summary>
        /// <param name="ti">Thumnail item to remove</param>
        /// <returns>True or False</returns>
        public bool RemoveItems(ThumbItem ti)
        {
            bool i = _items.Remove(ti);
            if (i)
            {
                _selectedIndex = -1;
            }
            return i;
        }

        /// <summary>
        /// Remove a thumbanil item at itemIndex
        /// </summary>
        /// <param name="itemIndex">Index of item to remove</param>
        public void RemoveItems(int itemIndex)
        {
            _items.RemoveAt(itemIndex);
            _selectedIndex = -1;
        }

        /// <summary>
        /// Empty thumbnailBar
        /// </summary>
        public void RemoveAll()
        {
            _items.Clear();
            _selectedIndex = -1;
        }

        /// <summary>
        /// Insert a thumbnail items to thumbnail bar
        /// </summary>
        /// <param name="index">Index of item</param>
        /// <param name="ti">Item</param>
        public void InsertItems(int index, ThumbItem ti)
        {
            _items.Insert(index, ti);            
        }


        /// <summary>
        /// Refresh item
        /// </summary>
        public void LoadThumbnailItems()
        {
            //int x = 5; //original X
            //int y = 6; //original Y

            //this.Controls.Clear(); //clear all control

            //for (int i = 0; i < _items.Count; i++)
            //{
            //    ThumbItem ti = _items[i];
            //    ti.Location = new Point(x, y); //locate new position
            //    x = x + ti.Width + 5;

            //    if (i == _selectedIndex) //selected if true
            //    {
            //        ti.IsSelected = true;                    
            //    }

            //    this.Controls.Add(ti);//add item to thumbnail bar
            //    tip.SetToolTip(ti, ti.ImagePath);//add tooltip
            //}

            //if (_selectedIndex > -1)
            //{
            //    this.ScrollControlIntoView(_items[_selectedIndex]);
            //}

            this.Controls.Clear(); //clear all control
            LoadThumbnailItems(0);
        }

        public void LoadThumbnailItems(int indexBeginAt)
        {
            int x = 5; //original X
            int y = 6; //original Y

            if (this.Controls.Count > 0 && _loadedIndex > 0)//get continue of position
            {
                x = 5 + this.Controls[_loadedIndex - 1].Location.X +
                        this.Controls[_loadedIndex - 1].Width;
            }

            for (int i = indexBeginAt; i < _items.Count; i++)
            {
                ThumbItem ti = _items[i];

                ti.Location = new Point(x, y); //locate new position
                x = x + ti.Width + 5;

                if (i == _selectedIndex) //selected if true
                {
                    ti.IsSelected = true;
                }

                this.Controls.Add(ti);//add item to thumbnail bar
                tip.SetToolTip(ti, ti.ImagePath);//add tooltip
            }

            if (SelectedIndex > -1)
            {
                this.ScrollControlIntoView(_items[_selectedIndex]);
            }

        }

        #endregion

        private void timRefreshFile_Tick(object sender, EventArgs e)
        {
            if (this.Controls.Count < _items.Count)
            {
                if (this.Controls.Count == 0)
                {
                    _loadedIndex = 0;
                }
                else
                {
                    _loadedIndex = this.Controls.Count - 1;
                }

                LoadThumbnailItems(_loadedIndex);
            }
            else
            {
                timRefreshFile.Enabled = false;
            }
                
        }








    }
}
