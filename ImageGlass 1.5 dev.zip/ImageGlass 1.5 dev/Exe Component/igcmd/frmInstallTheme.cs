﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using Ionic.Zip;
using System.Threading;

namespace igcmd
{
    public partial class frmInstallTheme : Form
    {
        public frmInstallTheme()
        {
            InitializeComponent();
        }

        private void frmInstallTheme_Load(object sender, EventArgs e)
        {
            //cmd: iginstalltheme "srcFile"

            lblStatus.Text = "Installing ...";
            Thread t = new Thread(new ThreadStart(InstallTheme));
            t.Priority = ThreadPriority.BelowNormal;
            t.IsBackground = true;
            t.Start();
        }

        /// <summary>
        /// Cài đặt theme
        /// </summary>
        private void InstallTheme()
        {
            string file = Program.args[1];
            if (!File.Exists(file))
            {
                return;
            }

            Directory.CreateDirectory(Program.igPath + "Themes\\");

            using (ZipFile z = new ZipFile(file, Encoding.UTF8))
            {
                z.ExtractProgress += new EventHandler<ExtractProgressEventArgs>(z_ExtractProgress);
                z.ZipError += new EventHandler<ZipErrorEventArgs>(z_ZipError);

                z.ExtractAll(Program.igPath + "Themes\\", ExtractExistingFileAction.OverwriteSilently);
            };

        }

        void z_ZipError(object sender, ZipErrorEventArgs e)
        {
            picStatus.Image = igcmd.Properties.Resources._del_2;
            lblStatus.Text = "Theme error!";
        }

        void z_ExtractProgress(object sender, ExtractProgressEventArgs e)
        {
            if (e.EntriesExtracted == e.EntriesTotal)
            {
                picStatus.Image = igcmd.Properties.Resources.check;
                lblStatus.Text = "Install successful!";
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnOpen_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("explorer.exe", Program.igPath + "Themes\\");
        }

       
    }
}
