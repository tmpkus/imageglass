﻿namespace ImageGlass
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            ImageGlass.Viewer.BackgroundTemplate backgroundTemplate1 = new ImageGlass.Viewer.BackgroundTemplate();
            this.toolBar = new System.Windows.Forms.ToolStrip();
            this.btnPrevious = new System.Windows.Forms.ToolStripButton();
            this.btnNext = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.btnRotateLeft = new System.Windows.Forms.ToolStripButton();
            this.btnRotateRight = new System.Windows.Forms.ToolStripButton();
            this.btnZoomIn = new System.Windows.Forms.ToolStripButton();
            this.btnZoomOut = new System.Windows.Forms.ToolStripButton();
            this.btnAutoSize = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.btnOpen = new System.Windows.Forms.ToolStripButton();
            this.btnRefresh = new System.Windows.Forms.ToolStripButton();
            this.btnGoto = new System.Windows.Forms.ToolStripButton();
            this.btnThumbnail = new System.Windows.Forms.ToolStripButton();
            this.btnBackground = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.btnFullscreen = new System.Windows.Forms.ToolStripButton();
            this.btnSlideshow = new System.Windows.Forms.ToolStripButton();
            this.btnConvert = new System.Windows.Forms.ToolStripButton();
            this.btnPrint = new System.Windows.Forms.ToolStripButton();
            this.btnAttachEmail = new System.Windows.Forms.ToolStripButton();
            this.btnUpload = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.lblInfo = new System.Windows.Forms.ToolStripLabel();
            this.btnMenu = new System.Windows.Forms.ToolStripDropDownButton();
            this.mnuMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.mnuOpen = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuOpenExistingFile = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem15 = new System.Windows.Forms.ToolStripSeparator();
            this.mnuOpenFromClipboard = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuConvert = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuEdit = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuEditPaint = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem16 = new System.Windows.Forms.ToolStripSeparator();
            this.mnuViewNext = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuViewPrevious = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripSeparator();
            this.mnuAlbumCollection = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuNewAlbum = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuAlbumOpen = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuAlbumSave = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuAlbumAddImage = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem9 = new System.Windows.Forms.ToolStripSeparator();
            this.mnuAlbumManager = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuView = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuViewAutoHideToolBar = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuViewShowThumbnailBar = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.mnuViewShowBackground = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuShowScrollBar = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuThumbBar = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuThumbBarRefresh = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuThumbBarShowTooltip = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuImage = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuImageZoomIn = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuImageZoomOut = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuImageAutoSize = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuImageActualSize = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripSeparator();
            this.mnuImageLeftRotate = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuImageRightRotate = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripSeparator();
            this.mnuImageGoto = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuImageFullScreen = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuImageSlideshow = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem7 = new System.Windows.Forms.ToolStripSeparator();
            this.mnuImageSetAsDesktopBackground = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuImageCopy = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuImageCopyFile = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuImageCoOpyPixel = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuImageCopyPath = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuImageExtractFrame = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuImageRecycleBin = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuImageDelete = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem8 = new System.Windows.Forms.ToolStripSeparator();
            this.mnuImageOpenLocation = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuImageProperties = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripSeparator();
            this.mnuPrint = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuAttachEmail = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuSharing = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem10 = new System.Windows.Forms.ToolStripSeparator();
            this.mnuTools = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuToolsPluginManager = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem11 = new System.Windows.Forms.ToolStripSeparator();
            this.mnuOptions = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuHelpAbout = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem12 = new System.Windows.Forms.ToolStripSeparator();
            this.mnuHelpOnline = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuHelpReport = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem13 = new System.Windows.Forms.ToolStripSeparator();
            this.mnuHelpDonate = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuHelpAdvertisement = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem14 = new System.Windows.Forms.ToolStripSeparator();
            this.mnuExit = new System.Windows.Forms.ToolStripMenuItem();
            this.thumbBar = new ImageGlass.ThumbBar.ThumbBar();
            this.imgView = new ImageGlass.Viewer.Viewer();
            this.toolBar.SuspendLayout();
            this.mnuMenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolBar
            // 
            this.toolBar.AutoSize = false;
            this.toolBar.BackColor = System.Drawing.Color.Transparent;
            this.toolBar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("toolBar.BackgroundImage")));
            this.toolBar.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.toolBar.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.toolBar.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnPrevious,
            this.btnNext,
            this.toolStripSeparator1,
            this.btnRotateLeft,
            this.btnRotateRight,
            this.btnZoomIn,
            this.btnZoomOut,
            this.btnAutoSize,
            this.toolStripSeparator2,
            this.btnOpen,
            this.btnRefresh,
            this.btnGoto,
            this.btnThumbnail,
            this.btnBackground,
            this.toolStripSeparator3,
            this.btnFullscreen,
            this.btnSlideshow,
            this.btnConvert,
            this.btnPrint,
            this.btnAttachEmail,
            this.btnUpload,
            this.toolStripSeparator4,
            this.lblInfo,
            this.btnMenu});
            this.toolBar.Location = new System.Drawing.Point(0, 0);
            this.toolBar.Name = "toolBar";
            this.toolBar.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
            this.toolBar.Size = new System.Drawing.Size(908, 33);
            this.toolBar.TabIndex = 2;
            this.toolBar.Text = "toolStrip1";
            // 
            // btnPrevious
            // 
            this.btnPrevious.AutoSize = false;
            this.btnPrevious.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnPrevious.Image = ((System.Drawing.Image)(resources.GetObject("btnPrevious.Image")));
            this.btnPrevious.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnPrevious.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnPrevious.Margin = new System.Windows.Forms.Padding(3, 1, 0, 2);
            this.btnPrevious.Name = "btnPrevious";
            this.btnPrevious.Size = new System.Drawing.Size(26, 28);
            this.btnPrevious.Click += new System.EventHandler(this.btnPrevious_Click);
            // 
            // btnNext
            // 
            this.btnNext.AutoSize = false;
            this.btnNext.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnNext.Image = ((System.Drawing.Image)(resources.GetObject("btnNext.Image")));
            this.btnNext.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnNext.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(26, 28);
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.AutoSize = false;
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 27);
            // 
            // btnRotateLeft
            // 
            this.btnRotateLeft.AutoSize = false;
            this.btnRotateLeft.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnRotateLeft.Image = ((System.Drawing.Image)(resources.GetObject("btnRotateLeft.Image")));
            this.btnRotateLeft.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnRotateLeft.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnRotateLeft.Name = "btnRotateLeft";
            this.btnRotateLeft.Size = new System.Drawing.Size(26, 28);
            // 
            // btnRotateRight
            // 
            this.btnRotateRight.AutoSize = false;
            this.btnRotateRight.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnRotateRight.Image = ((System.Drawing.Image)(resources.GetObject("btnRotateRight.Image")));
            this.btnRotateRight.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnRotateRight.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnRotateRight.Name = "btnRotateRight";
            this.btnRotateRight.Size = new System.Drawing.Size(26, 28);
            // 
            // btnZoomIn
            // 
            this.btnZoomIn.AutoSize = false;
            this.btnZoomIn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnZoomIn.Image = ((System.Drawing.Image)(resources.GetObject("btnZoomIn.Image")));
            this.btnZoomIn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnZoomIn.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnZoomIn.Name = "btnZoomIn";
            this.btnZoomIn.Size = new System.Drawing.Size(26, 28);
            // 
            // btnZoomOut
            // 
            this.btnZoomOut.AutoSize = false;
            this.btnZoomOut.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnZoomOut.Image = ((System.Drawing.Image)(resources.GetObject("btnZoomOut.Image")));
            this.btnZoomOut.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnZoomOut.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnZoomOut.Name = "btnZoomOut";
            this.btnZoomOut.Size = new System.Drawing.Size(26, 28);
            // 
            // btnAutoSize
            // 
            this.btnAutoSize.AutoSize = false;
            this.btnAutoSize.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnAutoSize.Image = ((System.Drawing.Image)(resources.GetObject("btnAutoSize.Image")));
            this.btnAutoSize.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnAutoSize.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnAutoSize.Name = "btnAutoSize";
            this.btnAutoSize.Size = new System.Drawing.Size(26, 28);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.AutoSize = false;
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 27);
            // 
            // btnOpen
            // 
            this.btnOpen.AutoSize = false;
            this.btnOpen.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnOpen.Image = ((System.Drawing.Image)(resources.GetObject("btnOpen.Image")));
            this.btnOpen.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnOpen.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnOpen.Name = "btnOpen";
            this.btnOpen.Size = new System.Drawing.Size(26, 28);
            this.btnOpen.Click += new System.EventHandler(this.btnOpen_Click);
            // 
            // btnRefresh
            // 
            this.btnRefresh.AutoSize = false;
            this.btnRefresh.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnRefresh.Image = ((System.Drawing.Image)(resources.GetObject("btnRefresh.Image")));
            this.btnRefresh.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnRefresh.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(26, 28);
            // 
            // btnGoto
            // 
            this.btnGoto.AutoSize = false;
            this.btnGoto.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnGoto.Image = ((System.Drawing.Image)(resources.GetObject("btnGoto.Image")));
            this.btnGoto.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnGoto.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnGoto.Name = "btnGoto";
            this.btnGoto.Size = new System.Drawing.Size(26, 28);
            // 
            // btnThumbnail
            // 
            this.btnThumbnail.AutoSize = false;
            this.btnThumbnail.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnThumbnail.Image = ((System.Drawing.Image)(resources.GetObject("btnThumbnail.Image")));
            this.btnThumbnail.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnThumbnail.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnThumbnail.Name = "btnThumbnail";
            this.btnThumbnail.Size = new System.Drawing.Size(26, 28);
            // 
            // btnBackground
            // 
            this.btnBackground.AutoSize = false;
            this.btnBackground.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnBackground.Image = ((System.Drawing.Image)(resources.GetObject("btnBackground.Image")));
            this.btnBackground.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnBackground.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnBackground.Name = "btnBackground";
            this.btnBackground.Size = new System.Drawing.Size(26, 28);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.AutoSize = false;
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 27);
            // 
            // btnFullscreen
            // 
            this.btnFullscreen.AutoSize = false;
            this.btnFullscreen.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnFullscreen.Image = ((System.Drawing.Image)(resources.GetObject("btnFullscreen.Image")));
            this.btnFullscreen.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnFullscreen.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnFullscreen.Name = "btnFullscreen";
            this.btnFullscreen.Size = new System.Drawing.Size(26, 28);
            // 
            // btnSlideshow
            // 
            this.btnSlideshow.AutoSize = false;
            this.btnSlideshow.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnSlideshow.Image = ((System.Drawing.Image)(resources.GetObject("btnSlideshow.Image")));
            this.btnSlideshow.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnSlideshow.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnSlideshow.Name = "btnSlideshow";
            this.btnSlideshow.Size = new System.Drawing.Size(26, 28);
            // 
            // btnConvert
            // 
            this.btnConvert.AutoSize = false;
            this.btnConvert.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnConvert.Image = ((System.Drawing.Image)(resources.GetObject("btnConvert.Image")));
            this.btnConvert.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnConvert.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnConvert.Name = "btnConvert";
            this.btnConvert.Size = new System.Drawing.Size(26, 28);
            // 
            // btnPrint
            // 
            this.btnPrint.AutoSize = false;
            this.btnPrint.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnPrint.Image = ((System.Drawing.Image)(resources.GetObject("btnPrint.Image")));
            this.btnPrint.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnPrint.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.Size = new System.Drawing.Size(26, 28);
            // 
            // btnAttachEmail
            // 
            this.btnAttachEmail.AutoSize = false;
            this.btnAttachEmail.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnAttachEmail.Image = ((System.Drawing.Image)(resources.GetObject("btnAttachEmail.Image")));
            this.btnAttachEmail.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnAttachEmail.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnAttachEmail.Name = "btnAttachEmail";
            this.btnAttachEmail.Size = new System.Drawing.Size(26, 28);
            // 
            // btnUpload
            // 
            this.btnUpload.AutoSize = false;
            this.btnUpload.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnUpload.Image = ((System.Drawing.Image)(resources.GetObject("btnUpload.Image")));
            this.btnUpload.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnUpload.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnUpload.Name = "btnUpload";
            this.btnUpload.Size = new System.Drawing.Size(26, 28);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.AutoSize = false;
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 27);
            // 
            // lblInfo
            // 
            this.lblInfo.AutoToolTip = true;
            this.lblInfo.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.lblInfo.Name = "lblInfo";
            this.lblInfo.Size = new System.Drawing.Size(189, 30);
            this.lblInfo.Text = "4/12 file(s)    782 x 2189 px    853 KB";
            // 
            // btnMenu
            // 
            this.btnMenu.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.btnMenu.AutoSize = false;
            this.btnMenu.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnMenu.DropDown = this.mnuMenu;
            this.btnMenu.Image = ((System.Drawing.Image)(resources.GetObject("btnMenu.Image")));
            this.btnMenu.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnMenu.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnMenu.Margin = new System.Windows.Forms.Padding(0, 1, 3, 2);
            this.btnMenu.Name = "btnMenu";
            this.btnMenu.Overflow = System.Windows.Forms.ToolStripItemOverflow.Never;
            this.btnMenu.ShowDropDownArrow = false;
            this.btnMenu.Size = new System.Drawing.Size(26, 28);
            // 
            // mnuMenu
            // 
            this.mnuMenu.BackColor = System.Drawing.SystemColors.Control;
            this.mnuMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuOpen,
            this.mnuConvert,
            this.mnuEdit,
            this.toolStripMenuItem16,
            this.mnuViewNext,
            this.mnuViewPrevious,
            this.toolStripMenuItem4,
            this.mnuAlbumCollection,
            this.mnuView,
            this.mnuThumbBar,
            this.mnuImage,
            this.toolStripMenuItem3,
            this.mnuPrint,
            this.mnuAttachEmail,
            this.mnuSharing,
            this.toolStripMenuItem10,
            this.mnuTools,
            this.mnuOptions,
            this.helpToolStripMenuItem,
            this.toolStripMenuItem14,
            this.mnuExit});
            this.mnuMenu.Name = "mnuMenu";
            this.mnuMenu.OwnerItem = this.btnMenu;
            this.mnuMenu.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
            this.mnuMenu.Size = new System.Drawing.Size(193, 386);
            // 
            // mnuOpen
            // 
            this.mnuOpen.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuOpenExistingFile,
            this.toolStripMenuItem15,
            this.mnuOpenFromClipboard});
            this.mnuOpen.Name = "mnuOpen";
            this.mnuOpen.Size = new System.Drawing.Size(192, 22);
            this.mnuOpen.Text = "&Open";
            // 
            // mnuOpenExistingFile
            // 
            this.mnuOpenExistingFile.Name = "mnuOpenExistingFile";
            this.mnuOpenExistingFile.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.O)));
            this.mnuOpenExistingFile.Size = new System.Drawing.Size(230, 22);
            this.mnuOpenExistingFile.Text = "&Existing file";
            this.mnuOpenExistingFile.Click += new System.EventHandler(this.mnuOpenExistingFile_Click);
            // 
            // toolStripMenuItem15
            // 
            this.toolStripMenuItem15.Name = "toolStripMenuItem15";
            this.toolStripMenuItem15.Size = new System.Drawing.Size(227, 6);
            // 
            // mnuOpenFromClipboard
            // 
            this.mnuOpenFromClipboard.Name = "mnuOpenFromClipboard";
            this.mnuOpenFromClipboard.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.V)));
            this.mnuOpenFromClipboard.Size = new System.Drawing.Size(230, 22);
            this.mnuOpenFromClipboard.Text = "&Image from clipboard";
            // 
            // mnuConvert
            // 
            this.mnuConvert.Name = "mnuConvert";
            this.mnuConvert.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this.mnuConvert.Size = new System.Drawing.Size(192, 22);
            this.mnuConvert.Text = "&Convert image";
            // 
            // mnuEdit
            // 
            this.mnuEdit.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuEditPaint});
            this.mnuEdit.Name = "mnuEdit";
            this.mnuEdit.Size = new System.Drawing.Size(192, 22);
            this.mnuEdit.Text = "&Edit";
            // 
            // mnuEditPaint
            // 
            this.mnuEditPaint.Name = "mnuEditPaint";
            this.mnuEditPaint.Size = new System.Drawing.Size(121, 22);
            this.mnuEditPaint.Text = "MS &Paint";
            // 
            // toolStripMenuItem16
            // 
            this.toolStripMenuItem16.Name = "toolStripMenuItem16";
            this.toolStripMenuItem16.Size = new System.Drawing.Size(189, 6);
            // 
            // mnuViewNext
            // 
            this.mnuViewNext.Name = "mnuViewNext";
            this.mnuViewNext.Size = new System.Drawing.Size(192, 22);
            this.mnuViewNext.Text = "Next image";
            // 
            // mnuViewPrevious
            // 
            this.mnuViewPrevious.Name = "mnuViewPrevious";
            this.mnuViewPrevious.Size = new System.Drawing.Size(192, 22);
            this.mnuViewPrevious.Text = "Previous image";
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(189, 6);
            // 
            // mnuAlbumCollection
            // 
            this.mnuAlbumCollection.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuNewAlbum,
            this.mnuAlbumOpen,
            this.mnuAlbumSave,
            this.mnuAlbumAddImage,
            this.toolStripMenuItem9,
            this.mnuAlbumManager});
            this.mnuAlbumCollection.Name = "mnuAlbumCollection";
            this.mnuAlbumCollection.Size = new System.Drawing.Size(192, 22);
            this.mnuAlbumCollection.Text = "&Album collection";
            // 
            // mnuNewAlbum
            // 
            this.mnuNewAlbum.Name = "mnuNewAlbum";
            this.mnuNewAlbum.Size = new System.Drawing.Size(172, 22);
            this.mnuNewAlbum.Text = "&New empty album";
            // 
            // mnuAlbumOpen
            // 
            this.mnuAlbumOpen.Name = "mnuAlbumOpen";
            this.mnuAlbumOpen.Size = new System.Drawing.Size(172, 22);
            this.mnuAlbumOpen.Text = "&Open album";
            // 
            // mnuAlbumSave
            // 
            this.mnuAlbumSave.Name = "mnuAlbumSave";
            this.mnuAlbumSave.Size = new System.Drawing.Size(172, 22);
            this.mnuAlbumSave.Text = "&Save album";
            // 
            // mnuAlbumAddImage
            // 
            this.mnuAlbumAddImage.Name = "mnuAlbumAddImage";
            this.mnuAlbumAddImage.Size = new System.Drawing.Size(172, 22);
            this.mnuAlbumAddImage.Text = "&Add image";
            // 
            // toolStripMenuItem9
            // 
            this.toolStripMenuItem9.Name = "toolStripMenuItem9";
            this.toolStripMenuItem9.Size = new System.Drawing.Size(169, 6);
            // 
            // mnuAlbumManager
            // 
            this.mnuAlbumManager.Name = "mnuAlbumManager";
            this.mnuAlbumManager.Size = new System.Drawing.Size(172, 22);
            this.mnuAlbumManager.Text = "Album &manager";
            // 
            // mnuView
            // 
            this.mnuView.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuViewAutoHideToolBar,
            this.mnuViewShowThumbnailBar,
            this.toolStripMenuItem1,
            this.mnuViewShowBackground,
            this.mnuShowScrollBar});
            this.mnuView.Name = "mnuView";
            this.mnuView.Size = new System.Drawing.Size(192, 22);
            this.mnuView.Text = "&View";
            // 
            // mnuViewAutoHideToolBar
            // 
            this.mnuViewAutoHideToolBar.Name = "mnuViewAutoHideToolBar";
            this.mnuViewAutoHideToolBar.Size = new System.Drawing.Size(211, 22);
            this.mnuViewAutoHideToolBar.Text = "Auto hide &Tool bar";
            // 
            // mnuViewShowThumbnailBar
            // 
            this.mnuViewShowThumbnailBar.Name = "mnuViewShowThumbnailBar";
            this.mnuViewShowThumbnailBar.Size = new System.Drawing.Size(211, 22);
            this.mnuViewShowThumbnailBar.Text = "Show &Thumbnail bar";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(208, 6);
            // 
            // mnuViewShowBackground
            // 
            this.mnuViewShowBackground.Name = "mnuViewShowBackground";
            this.mnuViewShowBackground.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.B)));
            this.mnuViewShowBackground.Size = new System.Drawing.Size(211, 22);
            this.mnuViewShowBackground.Text = "Show &Background";
            // 
            // mnuShowScrollBar
            // 
            this.mnuShowScrollBar.Name = "mnuShowScrollBar";
            this.mnuShowScrollBar.Size = new System.Drawing.Size(211, 22);
            this.mnuShowScrollBar.Text = "Show &Scroll bar";
            // 
            // mnuThumbBar
            // 
            this.mnuThumbBar.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuThumbBarRefresh,
            this.mnuThumbBarShowTooltip});
            this.mnuThumbBar.Name = "mnuThumbBar";
            this.mnuThumbBar.Size = new System.Drawing.Size(192, 22);
            this.mnuThumbBar.Text = "Thum&bnail bar";
            // 
            // mnuThumbBarRefresh
            // 
            this.mnuThumbBarRefresh.Name = "mnuThumbBarRefresh";
            this.mnuThumbBarRefresh.Size = new System.Drawing.Size(168, 22);
            this.mnuThumbBarRefresh.Text = "&Refresh";
            // 
            // mnuThumbBarShowTooltip
            // 
            this.mnuThumbBarShowTooltip.Name = "mnuThumbBarShowTooltip";
            this.mnuThumbBarShowTooltip.Size = new System.Drawing.Size(168, 22);
            this.mnuThumbBarShowTooltip.Text = "Show item &tooltip";
            // 
            // mnuImage
            // 
            this.mnuImage.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuImageZoomIn,
            this.mnuImageZoomOut,
            this.mnuImageAutoSize,
            this.mnuImageActualSize,
            this.toolStripMenuItem6,
            this.mnuImageLeftRotate,
            this.mnuImageRightRotate,
            this.toolStripMenuItem5,
            this.mnuImageGoto,
            this.mnuImageFullScreen,
            this.mnuImageSlideshow,
            this.toolStripMenuItem7,
            this.mnuImageSetAsDesktopBackground,
            this.mnuImageCopy,
            this.mnuImageExtractFrame,
            this.mnuImageRecycleBin,
            this.mnuImageDelete,
            this.toolStripMenuItem8,
            this.mnuImageOpenLocation,
            this.mnuImageProperties});
            this.mnuImage.Name = "mnuImage";
            this.mnuImage.Size = new System.Drawing.Size(192, 22);
            this.mnuImage.Text = "&Image";
            // 
            // mnuImageZoomIn
            // 
            this.mnuImageZoomIn.Name = "mnuImageZoomIn";
            this.mnuImageZoomIn.ShortcutKeyDisplayString = "Ctrl+";
            this.mnuImageZoomIn.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Oemplus)));
            this.mnuImageZoomIn.Size = new System.Drawing.Size(243, 22);
            this.mnuImageZoomIn.Text = "Zoom &in";
            // 
            // mnuImageZoomOut
            // 
            this.mnuImageZoomOut.Name = "mnuImageZoomOut";
            this.mnuImageZoomOut.ShortcutKeyDisplayString = "Ctrl-";
            this.mnuImageZoomOut.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.OemMinus)));
            this.mnuImageZoomOut.Size = new System.Drawing.Size(243, 22);
            this.mnuImageZoomOut.Text = "Zoom &out";
            // 
            // mnuImageAutoSize
            // 
            this.mnuImageAutoSize.Name = "mnuImageAutoSize";
            this.mnuImageAutoSize.Size = new System.Drawing.Size(243, 22);
            this.mnuImageAutoSize.Text = "A&uto size";
            // 
            // mnuImageActualSize
            // 
            this.mnuImageActualSize.Name = "mnuImageActualSize";
            this.mnuImageActualSize.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.D0)));
            this.mnuImageActualSize.Size = new System.Drawing.Size(243, 22);
            this.mnuImageActualSize.Text = "&Actual size";
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.Size = new System.Drawing.Size(240, 6);
            // 
            // mnuImageLeftRotate
            // 
            this.mnuImageLeftRotate.Name = "mnuImageLeftRotate";
            this.mnuImageLeftRotate.ShortcutKeyDisplayString = "Ctrl+,";
            this.mnuImageLeftRotate.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Oemcomma)));
            this.mnuImageLeftRotate.Size = new System.Drawing.Size(243, 22);
            this.mnuImageLeftRotate.Text = "&Left rotate";
            // 
            // mnuImageRightRotate
            // 
            this.mnuImageRightRotate.Name = "mnuImageRightRotate";
            this.mnuImageRightRotate.ShortcutKeyDisplayString = "Ctrl+.";
            this.mnuImageRightRotate.Size = new System.Drawing.Size(243, 22);
            this.mnuImageRightRotate.Text = "&Right rotate";
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(240, 6);
            // 
            // mnuImageGoto
            // 
            this.mnuImageGoto.Name = "mnuImageGoto";
            this.mnuImageGoto.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.G)));
            this.mnuImageGoto.Size = new System.Drawing.Size(243, 22);
            this.mnuImageGoto.Text = "&Goto image";
            // 
            // mnuImageFullScreen
            // 
            this.mnuImageFullScreen.Name = "mnuImageFullScreen";
            this.mnuImageFullScreen.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.F)));
            this.mnuImageFullScreen.Size = new System.Drawing.Size(243, 22);
            this.mnuImageFullScreen.Text = "&Full screen";
            // 
            // mnuImageSlideshow
            // 
            this.mnuImageSlideshow.Name = "mnuImageSlideshow";
            this.mnuImageSlideshow.ShortcutKeys = System.Windows.Forms.Keys.F11;
            this.mnuImageSlideshow.Size = new System.Drawing.Size(243, 22);
            this.mnuImageSlideshow.Text = "&Slide show";
            // 
            // toolStripMenuItem7
            // 
            this.toolStripMenuItem7.Name = "toolStripMenuItem7";
            this.toolStripMenuItem7.Size = new System.Drawing.Size(240, 6);
            // 
            // mnuImageSetAsDesktopBackground
            // 
            this.mnuImageSetAsDesktopBackground.Name = "mnuImageSetAsDesktopBackground";
            this.mnuImageSetAsDesktopBackground.Size = new System.Drawing.Size(243, 22);
            this.mnuImageSetAsDesktopBackground.Text = "Set as des&ktop background";
            // 
            // mnuImageCopy
            // 
            this.mnuImageCopy.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuImageCopyFile,
            this.mnuImageCoOpyPixel,
            this.mnuImageCopyPath});
            this.mnuImageCopy.Name = "mnuImageCopy";
            this.mnuImageCopy.Size = new System.Drawing.Size(243, 22);
            this.mnuImageCopy.Text = "&Copy";
            // 
            // mnuImageCopyFile
            // 
            this.mnuImageCopyFile.Name = "mnuImageCopyFile";
            this.mnuImageCopyFile.Size = new System.Drawing.Size(162, 22);
            this.mnuImageCopyFile.Text = "Image &file";
            // 
            // mnuImageCoOpyPixel
            // 
            this.mnuImageCoOpyPixel.Name = "mnuImageCoOpyPixel";
            this.mnuImageCoOpyPixel.Size = new System.Drawing.Size(162, 22);
            this.mnuImageCoOpyPixel.Text = "Image &pixels";
            // 
            // mnuImageCopyPath
            // 
            this.mnuImageCopyPath.Name = "mnuImageCopyPath";
            this.mnuImageCopyPath.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.C)));
            this.mnuImageCopyPath.Size = new System.Drawing.Size(162, 22);
            this.mnuImageCopyPath.Text = "Full &path";
            // 
            // mnuImageExtractFrame
            // 
            this.mnuImageExtractFrame.Name = "mnuImageExtractFrame";
            this.mnuImageExtractFrame.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.E)));
            this.mnuImageExtractFrame.Size = new System.Drawing.Size(243, 22);
            this.mnuImageExtractFrame.Text = "&Extract image frames";
            // 
            // mnuImageRecycleBin
            // 
            this.mnuImageRecycleBin.Name = "mnuImageRecycleBin";
            this.mnuImageRecycleBin.ShortcutKeys = System.Windows.Forms.Keys.Delete;
            this.mnuImageRecycleBin.Size = new System.Drawing.Size(243, 22);
            this.mnuImageRecycleBin.Text = "&Move to recycle bin";
            // 
            // mnuImageDelete
            // 
            this.mnuImageDelete.Name = "mnuImageDelete";
            this.mnuImageDelete.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Shift | System.Windows.Forms.Keys.Delete)));
            this.mnuImageDelete.Size = new System.Drawing.Size(243, 22);
            this.mnuImageDelete.Text = "&Delete from hard disk";
            // 
            // toolStripMenuItem8
            // 
            this.toolStripMenuItem8.Name = "toolStripMenuItem8";
            this.toolStripMenuItem8.Size = new System.Drawing.Size(240, 6);
            // 
            // mnuImageOpenLocation
            // 
            this.mnuImageOpenLocation.Name = "mnuImageOpenLocation";
            this.mnuImageOpenLocation.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.L)));
            this.mnuImageOpenLocation.Size = new System.Drawing.Size(243, 22);
            this.mnuImageOpenLocation.Text = "Open image &location";
            // 
            // mnuImageProperties
            // 
            this.mnuImageProperties.Name = "mnuImageProperties";
            this.mnuImageProperties.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.I)));
            this.mnuImageProperties.Size = new System.Drawing.Size(243, 22);
            this.mnuImageProperties.Text = "&Properties";
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(189, 6);
            // 
            // mnuPrint
            // 
            this.mnuPrint.Name = "mnuPrint";
            this.mnuPrint.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.P)));
            this.mnuPrint.Size = new System.Drawing.Size(192, 22);
            this.mnuPrint.Text = "&Print";
            // 
            // mnuAttachEmail
            // 
            this.mnuAttachEmail.Name = "mnuAttachEmail";
            this.mnuAttachEmail.Size = new System.Drawing.Size(192, 22);
            this.mnuAttachEmail.Text = "Attach to e&mail";
            // 
            // mnuSharing
            // 
            this.mnuSharing.Name = "mnuSharing";
            this.mnuSharing.Size = new System.Drawing.Size(192, 22);
            this.mnuSharing.Text = "&Sharing...";
            // 
            // toolStripMenuItem10
            // 
            this.toolStripMenuItem10.Name = "toolStripMenuItem10";
            this.toolStripMenuItem10.Size = new System.Drawing.Size(189, 6);
            // 
            // mnuTools
            // 
            this.mnuTools.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuToolsPluginManager,
            this.toolStripMenuItem11});
            this.mnuTools.Name = "mnuTools";
            this.mnuTools.Size = new System.Drawing.Size(192, 22);
            this.mnuTools.Text = "Too&ls";
            // 
            // mnuToolsPluginManager
            // 
            this.mnuToolsPluginManager.Name = "mnuToolsPluginManager";
            this.mnuToolsPluginManager.Size = new System.Drawing.Size(158, 22);
            this.mnuToolsPluginManager.Text = "Plugin manager";
            // 
            // toolStripMenuItem11
            // 
            this.toolStripMenuItem11.Name = "toolStripMenuItem11";
            this.toolStripMenuItem11.Size = new System.Drawing.Size(155, 6);
            // 
            // mnuOptions
            // 
            this.mnuOptions.Name = "mnuOptions";
            this.mnuOptions.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Shift) 
            | System.Windows.Forms.Keys.P)));
            this.mnuOptions.Size = new System.Drawing.Size(192, 22);
            this.mnuOptions.Text = "Optio&ns";
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuHelpAbout,
            this.toolStripMenuItem12,
            this.mnuHelpOnline,
            this.mnuHelpReport,
            this.toolStripMenuItem13,
            this.mnuHelpDonate,
            this.mnuHelpAdvertisement});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(192, 22);
            this.helpToolStripMenuItem.Text = "&Help";
            // 
            // mnuHelpAbout
            // 
            this.mnuHelpAbout.Name = "mnuHelpAbout";
            this.mnuHelpAbout.ShortcutKeys = System.Windows.Forms.Keys.F1;
            this.mnuHelpAbout.Size = new System.Drawing.Size(197, 22);
            this.mnuHelpAbout.Text = "&About ImageGlass";
            // 
            // toolStripMenuItem12
            // 
            this.toolStripMenuItem12.Name = "toolStripMenuItem12";
            this.toolStripMenuItem12.Size = new System.Drawing.Size(194, 6);
            // 
            // mnuHelpOnline
            // 
            this.mnuHelpOnline.Name = "mnuHelpOnline";
            this.mnuHelpOnline.Size = new System.Drawing.Size(197, 22);
            this.mnuHelpOnline.Text = "&Get help online";
            // 
            // mnuHelpReport
            // 
            this.mnuHelpReport.Name = "mnuHelpReport";
            this.mnuHelpReport.Size = new System.Drawing.Size(197, 22);
            this.mnuHelpReport.Text = "&Report bugs";
            // 
            // toolStripMenuItem13
            // 
            this.toolStripMenuItem13.Name = "toolStripMenuItem13";
            this.toolStripMenuItem13.Size = new System.Drawing.Size(194, 6);
            // 
            // mnuHelpDonate
            // 
            this.mnuHelpDonate.Name = "mnuHelpDonate";
            this.mnuHelpDonate.Size = new System.Drawing.Size(197, 22);
            this.mnuHelpDonate.Text = "&Donate";
            // 
            // mnuHelpAdvertisement
            // 
            this.mnuHelpAdvertisement.Name = "mnuHelpAdvertisement";
            this.mnuHelpAdvertisement.Size = new System.Drawing.Size(197, 22);
            this.mnuHelpAdvertisement.Text = "&Make an advertisement";
            // 
            // toolStripMenuItem14
            // 
            this.toolStripMenuItem14.Name = "toolStripMenuItem14";
            this.toolStripMenuItem14.Size = new System.Drawing.Size(189, 6);
            // 
            // mnuExit
            // 
            this.mnuExit.Name = "mnuExit";
            this.mnuExit.ShortcutKeyDisplayString = "";
            this.mnuExit.Size = new System.Drawing.Size(192, 22);
            this.mnuExit.Text = "E&xit";
            // 
            // thumbBar
            // 
            this.thumbBar.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.thumbBar.AutoScroll = true;
            this.thumbBar.BackColor = System.Drawing.Color.Transparent;
            this.thumbBar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("thumbBar.BackgroundImage")));
            this.thumbBar.ColorDown = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.thumbBar.ColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.thumbBar.ColorNormal = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.thumbBar.ColorSelected = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.thumbBar.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.thumbBar.IsShowTooltip = true;
            this.thumbBar.Location = new System.Drawing.Point(0, 305);
            this.thumbBar.MinimumSize = new System.Drawing.Size(10, 115);
            this.thumbBar.Name = "thumbBar";
            this.thumbBar.SelectedIndex = -1;
            this.thumbBar.Size = new System.Drawing.Size(908, 115);
            this.thumbBar.TabIndex = 0;
            this.thumbBar.MouseMove += new System.Windows.Forms.MouseEventHandler(this.frmMain_MouseMove);
            // 
            // imgView
            // 
            this.imgView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.imgView.BackColor = System.Drawing.Color.White;
            backgroundTemplate1.DistanceWidth = 10;
            backgroundTemplate1.HorizontalColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(179)))), ((int)(((byte)(206)))), ((int)(((byte)(236)))));
            backgroundTemplate1.HorizontalWidth = 1;
            backgroundTemplate1.VerticalColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(179)))), ((int)(((byte)(206)))), ((int)(((byte)(236)))));
            backgroundTemplate1.VerticalWidth = 1;
            this.imgView.BackgroundTemplate = backgroundTemplate1;
            this.imgView.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.imgView.Image = null;
            this.imgView.InitialImage = null;
            this.imgView.IsShowBackground = false;
            this.imgView.Location = new System.Drawing.Point(0, 34);
            this.imgView.Name = "imgView";
            this.imgView.Origin = new System.Drawing.Point(0, 0);
            this.imgView.PanButton = System.Windows.Forms.MouseButtons.Left;
            this.imgView.PanMode = true;
            this.imgView.ScrollbarsVisible = false;
            this.imgView.Size = new System.Drawing.Size(908, 270);
            this.imgView.StretchImageToFit = true;
            this.imgView.TabIndex = 0;
            this.imgView.ZoomFactor = 1D;
            this.imgView.ZoomOnMouseWheel = true;
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(908, 420);
            this.Controls.Add(this.toolBar);
            this.Controls.Add(this.thumbBar);
            this.Controls.Add(this.imgView);
            this.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmMain";
            this.Text = "ImageGlass";
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.frmMain_MouseMove);
            this.toolBar.ResumeLayout(false);
            this.toolBar.PerformLayout();
            this.mnuMenu.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private ThumbBar.ThumbBar thumbBar;
        private ImageGlass.Viewer.Viewer imgView;
        private System.Windows.Forms.ToolStrip toolBar;
        private System.Windows.Forms.ToolStripButton btnPrevious;
        private System.Windows.Forms.ToolStripButton btnNext;
        private System.Windows.Forms.ToolStripButton btnRotateLeft;
        private System.Windows.Forms.ToolStripButton btnRotateRight;
        private System.Windows.Forms.ToolStripButton btnZoomIn;
        private System.Windows.Forms.ToolStripButton btnZoomOut;
        private System.Windows.Forms.ToolStripButton btnAutoSize;
        private System.Windows.Forms.ToolStripButton btnOpen;
        private System.Windows.Forms.ToolStripButton btnRefresh;
        private System.Windows.Forms.ToolStripButton btnGoto;
        private System.Windows.Forms.ToolStripButton btnThumbnail;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripButton btnBackground;
        private System.Windows.Forms.ToolStripButton btnFullscreen;
        private System.Windows.Forms.ToolStripButton btnUpload;
        private System.Windows.Forms.ToolStripButton btnConvert;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripLabel lblInfo;
        private System.Windows.Forms.ToolStripButton btnSlideshow;
        private System.Windows.Forms.ToolStripButton btnPrint;
        private System.Windows.Forms.ToolStripButton btnAttachEmail;
        private System.Windows.Forms.ToolStripDropDownButton btnMenu;
        private System.Windows.Forms.ContextMenuStrip mnuMenu;
        private System.Windows.Forms.ToolStripMenuItem mnuAlbumCollection;
        private System.Windows.Forms.ToolStripMenuItem mnuNewAlbum;
        private System.Windows.Forms.ToolStripMenuItem mnuAlbumOpen;
        private System.Windows.Forms.ToolStripMenuItem mnuAlbumSave;
        private System.Windows.Forms.ToolStripMenuItem mnuView;
        private System.Windows.Forms.ToolStripMenuItem mnuViewShowBackground;
        private System.Windows.Forms.ToolStripMenuItem mnuShowScrollBar;
        private System.Windows.Forms.ToolStripMenuItem mnuThumbBar;
        private System.Windows.Forms.ToolStripMenuItem mnuThumbBarShowTooltip;
        private System.Windows.Forms.ToolStripMenuItem mnuOpen;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem4;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem mnuThumbBarRefresh;
        private System.Windows.Forms.ToolStripMenuItem mnuConvert;
        private System.Windows.Forms.ToolStripMenuItem mnuImage;
        private System.Windows.Forms.ToolStripMenuItem mnuImageZoomIn;
        private System.Windows.Forms.ToolStripMenuItem mnuImageZoomOut;
        private System.Windows.Forms.ToolStripMenuItem mnuImageAutoSize;
        private System.Windows.Forms.ToolStripMenuItem mnuImageActualSize;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem mnuImageLeftRotate;
        private System.Windows.Forms.ToolStripMenuItem mnuImageRightRotate;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem mnuImageGoto;
        private System.Windows.Forms.ToolStripMenuItem mnuImageFullScreen;
        private System.Windows.Forms.ToolStripMenuItem mnuImageSlideshow;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem mnuImageSetAsDesktopBackground;
        private System.Windows.Forms.ToolStripMenuItem mnuImageRecycleBin;
        private System.Windows.Forms.ToolStripMenuItem mnuImageDelete;
        private System.Windows.Forms.ToolStripMenuItem mnuImageExtractFrame;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem8;
        private System.Windows.Forms.ToolStripMenuItem mnuImageOpenLocation;
        private System.Windows.Forms.ToolStripMenuItem mnuImageProperties;
        private System.Windows.Forms.ToolStripMenuItem mnuEdit;
        private System.Windows.Forms.ToolStripMenuItem mnuEditPaint;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem9;
        private System.Windows.Forms.ToolStripMenuItem mnuAlbumManager;
        private System.Windows.Forms.ToolStripMenuItem mnuPrint;
        private System.Windows.Forms.ToolStripMenuItem mnuAttachEmail;
        private System.Windows.Forms.ToolStripMenuItem mnuSharing;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem10;
        private System.Windows.Forms.ToolStripMenuItem mnuTools;
        private System.Windows.Forms.ToolStripMenuItem mnuToolsPluginManager;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem11;
        private System.Windows.Forms.ToolStripMenuItem mnuOptions;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mnuHelpAbout;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem12;
        private System.Windows.Forms.ToolStripMenuItem mnuHelpOnline;
        private System.Windows.Forms.ToolStripMenuItem mnuHelpReport;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem13;
        private System.Windows.Forms.ToolStripMenuItem mnuHelpDonate;
        private System.Windows.Forms.ToolStripMenuItem mnuHelpAdvertisement;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem14;
        private System.Windows.Forms.ToolStripMenuItem mnuExit;
        private System.Windows.Forms.ToolStripMenuItem mnuImageCopy;
        private System.Windows.Forms.ToolStripMenuItem mnuImageCopyFile;
        private System.Windows.Forms.ToolStripMenuItem mnuImageCoOpyPixel;
        private System.Windows.Forms.ToolStripMenuItem mnuImageCopyPath;
        private System.Windows.Forms.ToolStripMenuItem mnuOpenExistingFile;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem15;
        private System.Windows.Forms.ToolStripMenuItem mnuOpenFromClipboard;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem16;
        private System.Windows.Forms.ToolStripMenuItem mnuViewNext;
        private System.Windows.Forms.ToolStripMenuItem mnuViewPrevious;
        private System.Windows.Forms.ToolStripMenuItem mnuAlbumAddImage;
        private System.Windows.Forms.ToolStripMenuItem mnuViewAutoHideToolBar;
        private System.Windows.Forms.ToolStripMenuItem mnuViewShowThumbnailBar;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;

    }
}

