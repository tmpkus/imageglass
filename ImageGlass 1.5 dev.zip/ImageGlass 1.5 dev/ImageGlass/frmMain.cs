﻿/*
ImageGlass Project - Image viewer for Windows
Copyright (C) 2012 DUONG DIEU PHAP
Project homepage: http://imageglass.codeplex.com

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.IO;
using ImageGlass.Core;
using ImageGlass.Feature;

namespace ImageGlass
{
    public partial class frmMain : Form
    {

        #region Local Variable

        private ImageGlass.Core.ImageList _dsImage;               //Loading image array
        private int _currentIndex;          //Current viewing image index
        private string _currentImageFilename;      //Current viewing image full path
        private bool _isSlideShow;           //Is slideshow starting?
        private bool _isLoadRecursiveDir;    //Load image from recursive directory
        private bool _isImageError;          //Is image error?
        private List<string> _dsExtension;           //Extension array support

        #endregion

        #region Initialize ImageGlass

        /// <summary>
        /// Initialize local variable with default value
        /// </summary>
        private void InitLocalVariable()
        {
            _dsImage = new ImageGlass.Core.ImageList();
            _currentIndex       = 0;
            _currentImageFilename = string.Empty;
            _isSlideShow        = false;
            _isLoadRecursiveDir = false; 
            _isImageError       = false;

            //extension support
            string[] ext        = {".bmp", ".dib", ".jpg", ".jpe", ".jfif", ".jpeg", 
                                    ".png", ".gif", ".ico", ".tif", ".tiff", ".emf",
                                    ".exif", ".wmf", ".tga"};
            _dsExtension = new List<string>();
            _dsExtension.AddRange(ext.ToList());
        }

        public frmMain()
        {
            InitializeComponent();
            InitLocalVariable();
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            
        }
        #endregion

        #region Processing Function

        /// <summary>
        /// Open an image to view
        /// </summary>
        private void OpenImage()
        {
            OpenFileDialog o = new OpenFileDialog();
            o.RestoreDirectory = true;
            o.CheckFileExists = true;
            o.CheckFileExists = true;

            if (o.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                imgView.Image = Image.FromFile(o.FileName);
                PreparingImage(o.FileName);

                ThumbBar.ClickEventHander eventClickItem = new ThumbBar.ClickEventHander(ti_Click);

                thumbBar.RemoveAll();
                thumbBar.AddItemsFromDir(Path.GetDirectoryName(o.FileName), eventClickItem);
                thumbBar.LoadThumbnailItems();

            }
        }


        void ti_Click(object sender, EventArgs e)
        {
            ThumbBar.ThumbItem ti = (ThumbBar.ThumbItem)sender;
            //ti.IsSelected = true;
            imgView.StretchImageToFit = true;
            imgView.Image = Image.FromFile(ti.ImagePath);
           
            for (int i = 0; i < thumbBar.Items.Count; i++)
            {
                if (thumbBar.Items[i] != ti)
                {
                    thumbBar.Items[i].IsSelected = false;
                }
            }


        }














        /// <summary>
        /// Prepare image information before display
        /// </summary>
        /// <param name="path">Image filename or Image folder</param>
        private void PreparingImage(string path)
        {
            //If path is filename
            if (File.Exists(path))
            {
                //save filename
                _currentImageFilename = path;

                //get folder of filename
                path = (Path.GetDirectoryName(path) + "\\").Replace("\\\\", "\\");
            }
                //If path is folder
            else if (Directory.Exists(path))
            {
                
            }
                //If path is not exist, exit sub
            else return;

            //Get images name in folder
            List<string> dsImage = new List<string>();
            GetImagesFromDir(ref dsImage, path);

            //Add all to list
            _dsImage.Dispose();
            _dsImage = new ImageGlass.Core.ImageList(dsImage.ToArray());

            //Show information of file
            this.Text = "ImageGlass - " + _currentImageFilename;
            lblInfo.Text = ImageGlass_ImageInfo.GetFileSize(_currentImageFilename);
            

            //Get image index
            _currentIndex = dsImage.IndexOf(_currentImageFilename);

            //If file is not exist in list
            if (_currentIndex < 0)
            {
                _isImageError = true;
                imgView.Image = _dsImage.GetErrorImage();
                return;
            }

            //Display image on viewer
            ShowImage(0);
        }

        /// <summary>
        /// Get all image files in folder
        /// </summary>
        /// <param name="dsFile">Return image list</param>
        /// <param name="path">Folder to search</param>
        private void GetImagesFromDir(ref List<string> dsFile, string path)
        {
            int a = dsFile.Count;
            dsFile.AddRange(System.IO.Directory.GetFiles(path));

            for (; a < dsFile.Count; a++)
            {
                string ext = Path.GetExtension(dsFile[a]);

                // loc lai danh sach cac file co ext ho tro
                if (_dsExtension.IndexOf(ext) == -1)
                {
                    dsFile.RemoveAt(a);
                    a--;
                }
            }

            //Recursive if TRUE
            if (_isLoadRecursiveDir)
            {
                string[] sub = System.IO.Directory.GetDirectories(path);
                foreach (string e in sub)
                {
                    GetImagesFromDir(ref dsFile, e);
                }
            }
        }

        /// <summary>
        /// View image
        /// </summary>
        /// <param name="stepValue">0 - current image, -1 - previous image, 1 - next image, ...</param>
        private void ShowImage(int stepValue)
        {
            //If there is no image in list
            if (_dsImage.GetTotalImage() < 1)
            {
                this.Text = "ImageGlass";
                lblInfo.Text = string.Empty;
                return;
            }

            //Increase current index
            _currentIndex += stepValue;

            //If _currentIndex is more than the last image, point it to the first image
            if (_currentIndex >= _dsImage.GetTotalImage()) _currentIndex = 0;

            //If _currentIndex is less than the first image, point it to the last image
            if (_currentIndex < 0) _currentIndex = _dsImage.GetTotalImage() - 1;

            //Clean graphic on viewer
            //imgView.Image = null;

            //Get info of image
            string strInfo = string.Empty;
            strInfo = (_currentIndex + 1).ToString() + "/" + _dsImage.GetTotalImage().ToString() + " file(s)    ";
            
            Image im = null;

            try
            {
                im = _dsImage.GetImage(_currentIndex);
                _isImageError = _dsImage.Items[_currentIndex].IsFailed;

                strInfo += im.Width + " x " + im.Height + " px    " +
                               ImageGlass_ImageInfo.GetFileSize(_dsImage.Items[_currentIndex].Path);
                imgView.Image = im;
                
            }
            catch//(Exception ex)
            {
                imgView.Image = null;
                if (!File.Exists(_dsImage.Items[_currentIndex].Path))
                {
                    _dsImage.UnloadImage(_currentIndex);
                }
            }

            //Boost next image
            _dsImage.IsBoostLoading = true;

            //Display info
            lblInfo.Text = strInfo;

            //Show thumbnail image
            //
            //

            //Collect garbage
            GC.Collect();            
        }



        #endregion

        private void btnOpen_Click(object sender, EventArgs e)
        {
            OpenImage();
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            ShowImage(1);
        }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            ShowImage(-1);
        }

        private void mnuOpenExistingFile_Click(object sender, EventArgs e)
        {
            OpenImage();
        }

        private void frmMain_MouseMove(object sender, MouseEventArgs e)
        {
            //this.Text = e.Y.ToString();

            //if (e.Y < 30)
            //{
            //    toolBar.Visible = true;
            //}
            //else
            //{
            //    toolBar.Visible = false;
            //}
        }









    }
}
