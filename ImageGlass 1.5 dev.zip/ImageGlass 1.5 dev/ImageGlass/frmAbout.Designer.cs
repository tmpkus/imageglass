﻿namespace ImageGlass
{
    partial class frmAbout
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmAbout));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblAbout = new System.Windows.Forms.Label();
            this.lblComponent = new System.Windows.Forms.Label();
            this.lblLink = new System.Windows.Forms.Label();
            this.lblDonate = new System.Windows.Forms.Label();
            this.panAbout = new System.Windows.Forms.Panel();
            this.lblVersion = new System.Windows.Forms.Label();
            this.lblCopyright = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.linkLabel2 = new System.Windows.Forms.LinkLabel();
            this.linkLabel3 = new System.Windows.Forms.LinkLabel();
            this.linkLabel4 = new System.Windows.Forms.LinkLabel();
            this.label2 = new System.Windows.Forms.Label();
            this.linkLabel5 = new System.Windows.Forms.LinkLabel();
            this.linkLabel6 = new System.Windows.Forms.LinkLabel();
            this.linkLabel7 = new System.Windows.Forms.LinkLabel();
            this.linkLabel8 = new System.Windows.Forms.LinkLabel();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.linkLabel9 = new System.Windows.Forms.LinkLabel();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panAbout.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(31, -8);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(260, 230);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // lblAbout
            // 
            this.lblAbout.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(130)))), ((int)(((byte)(0)))), ((int)(((byte)(138)))), ((int)(((byte)(232)))));
            this.lblAbout.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblAbout.Font = new System.Drawing.Font("Segoe UI", 15F);
            this.lblAbout.ForeColor = System.Drawing.Color.White;
            this.lblAbout.Location = new System.Drawing.Point(0, 252);
            this.lblAbout.Name = "lblAbout";
            this.lblAbout.Size = new System.Drawing.Size(216, 41);
            this.lblAbout.TabIndex = 1;
            this.lblAbout.Tag = "0";
            this.lblAbout.Text = "Thông tin     ";
            this.lblAbout.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblAbout.Click += new System.EventHandler(this.lblDonate_Click);
            this.lblAbout.MouseDown += new System.Windows.Forms.MouseEventHandler(this.lblDonate_MouseDown);
            this.lblAbout.MouseEnter += new System.EventHandler(this.lblDonate_MouseEnter);
            this.lblAbout.MouseLeave += new System.EventHandler(this.lblDonate_MouseLeave);
            this.lblAbout.MouseUp += new System.Windows.Forms.MouseEventHandler(this.lblDonate_MouseUp);
            // 
            // lblComponent
            // 
            this.lblComponent.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(138)))), ((int)(((byte)(232)))));
            this.lblComponent.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblComponent.Font = new System.Drawing.Font("Segoe UI", 15F);
            this.lblComponent.ForeColor = System.Drawing.Color.White;
            this.lblComponent.Location = new System.Drawing.Point(0, 293);
            this.lblComponent.Name = "lblComponent";
            this.lblComponent.Size = new System.Drawing.Size(216, 41);
            this.lblComponent.TabIndex = 2;
            this.lblComponent.Tag = "0";
            this.lblComponent.Text = "Thành phần     ";
            this.lblComponent.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblComponent.Click += new System.EventHandler(this.lblDonate_Click);
            this.lblComponent.MouseDown += new System.Windows.Forms.MouseEventHandler(this.lblDonate_MouseDown);
            this.lblComponent.MouseEnter += new System.EventHandler(this.lblDonate_MouseEnter);
            this.lblComponent.MouseLeave += new System.EventHandler(this.lblDonate_MouseLeave);
            this.lblComponent.MouseUp += new System.Windows.Forms.MouseEventHandler(this.lblDonate_MouseUp);
            // 
            // lblLink
            // 
            this.lblLink.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(138)))), ((int)(((byte)(232)))));
            this.lblLink.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblLink.Font = new System.Drawing.Font("Segoe UI", 15F);
            this.lblLink.ForeColor = System.Drawing.Color.White;
            this.lblLink.Location = new System.Drawing.Point(0, 334);
            this.lblLink.Name = "lblLink";
            this.lblLink.Size = new System.Drawing.Size(216, 41);
            this.lblLink.TabIndex = 3;
            this.lblLink.Tag = "0";
            this.lblLink.Text = "Liên kết     ";
            this.lblLink.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblLink.Click += new System.EventHandler(this.lblDonate_Click);
            this.lblLink.MouseDown += new System.Windows.Forms.MouseEventHandler(this.lblDonate_MouseDown);
            this.lblLink.MouseEnter += new System.EventHandler(this.lblDonate_MouseEnter);
            this.lblLink.MouseLeave += new System.EventHandler(this.lblDonate_MouseLeave);
            this.lblLink.MouseUp += new System.Windows.Forms.MouseEventHandler(this.lblDonate_MouseUp);
            // 
            // lblDonate
            // 
            this.lblDonate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(138)))), ((int)(((byte)(232)))));
            this.lblDonate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblDonate.Font = new System.Drawing.Font("Segoe UI", 15F);
            this.lblDonate.ForeColor = System.Drawing.Color.White;
            this.lblDonate.Location = new System.Drawing.Point(0, 375);
            this.lblDonate.Name = "lblDonate";
            this.lblDonate.Size = new System.Drawing.Size(216, 41);
            this.lblDonate.TabIndex = 4;
            this.lblDonate.Tag = "0";
            this.lblDonate.Text = "Tài trợ     ";
            this.lblDonate.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblDonate.Click += new System.EventHandler(this.lblDonate_Click);
            this.lblDonate.MouseDown += new System.Windows.Forms.MouseEventHandler(this.lblDonate_MouseDown);
            this.lblDonate.MouseEnter += new System.EventHandler(this.lblDonate_MouseEnter);
            this.lblDonate.MouseLeave += new System.EventHandler(this.lblDonate_MouseLeave);
            this.lblDonate.MouseUp += new System.Windows.Forms.MouseEventHandler(this.lblDonate_MouseUp);
            // 
            // panAbout
            // 
            this.panAbout.Controls.Add(this.linkLabel9);
            this.panAbout.Controls.Add(this.label4);
            this.panAbout.Controls.Add(this.label3);
            this.panAbout.Controls.Add(this.linkLabel8);
            this.panAbout.Controls.Add(this.linkLabel7);
            this.panAbout.Controls.Add(this.linkLabel6);
            this.panAbout.Controls.Add(this.linkLabel5);
            this.panAbout.Controls.Add(this.label2);
            this.panAbout.Controls.Add(this.linkLabel4);
            this.panAbout.Controls.Add(this.linkLabel3);
            this.panAbout.Controls.Add(this.linkLabel2);
            this.panAbout.Controls.Add(this.linkLabel1);
            this.panAbout.Controls.Add(this.label1);
            this.panAbout.Controls.Add(this.lblCopyright);
            this.panAbout.Controls.Add(this.lblVersion);
            this.panAbout.Location = new System.Drawing.Point(297, 12);
            this.panAbout.Name = "panAbout";
            this.panAbout.Size = new System.Drawing.Size(437, 450);
            this.panAbout.TabIndex = 5;
            // 
            // lblVersion
            // 
            this.lblVersion.AutoSize = true;
            this.lblVersion.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.lblVersion.Location = new System.Drawing.Point(19, 16);
            this.lblVersion.Name = "lblVersion";
            this.lblVersion.Size = new System.Drawing.Size(185, 21);
            this.lblVersion.TabIndex = 0;
            this.lblVersion.Text = "Phiên bản: 1.5.4423.3021";
            // 
            // lblCopyright
            // 
            this.lblCopyright.AutoSize = true;
            this.lblCopyright.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblCopyright.Location = new System.Drawing.Point(19, 55);
            this.lblCopyright.Name = "lblCopyright";
            this.lblCopyright.Size = new System.Drawing.Size(273, 38);
            this.lblCopyright.TabIndex = 1;
            this.lblCopyright.Text = "Copyright © 2010-2012 Dương Diệu Pháp\r\nAll rights reserver";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Underline);
            this.label1.Location = new System.Drawing.Point(19, 108);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 19);
            this.label1.TabIndex = 2;
            this.label1.Text = "Liên hệ:";
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.linkLabel1.LinkArea = new System.Windows.Forms.LinkArea(7, 23);
            this.linkLabel1.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.linkLabel1.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(131)))), ((int)(((byte)(244)))));
            this.linkLabel1.Location = new System.Drawing.Point(48, 136);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(166, 23);
            this.linkLabel1.TabIndex = 4;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "Email: d2phap@gmail.com";
            this.linkLabel1.UseCompatibleTextRendering = true;
            this.linkLabel1.VisitedLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(131)))), ((int)(((byte)(244)))));
            // 
            // linkLabel2
            // 
            this.linkLabel2.AutoSize = true;
            this.linkLabel2.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.linkLabel2.LinkArea = new System.Windows.Forms.LinkArea(7, 23);
            this.linkLabel2.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.linkLabel2.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(131)))), ((int)(((byte)(244)))));
            this.linkLabel2.Location = new System.Drawing.Point(48, 159);
            this.linkLabel2.Name = "linkLabel2";
            this.linkLabel2.Size = new System.Drawing.Size(94, 23);
            this.linkLabel2.TabIndex = 5;
            this.linkLabel2.TabStop = true;
            this.linkLabel2.Text = "Skype: d2phap";
            this.linkLabel2.UseCompatibleTextRendering = true;
            this.linkLabel2.VisitedLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(131)))), ((int)(((byte)(244)))));
            // 
            // linkLabel3
            // 
            this.linkLabel3.AutoSize = true;
            this.linkLabel3.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.linkLabel3.LinkArea = new System.Windows.Forms.LinkArea(17, 99);
            this.linkLabel3.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.linkLabel3.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(131)))), ((int)(((byte)(244)))));
            this.linkLabel3.Location = new System.Drawing.Point(48, 182);
            this.linkLabel3.Name = "linkLabel3";
            this.linkLabel3.Size = new System.Drawing.Size(233, 23);
            this.linkLabel3.TabIndex = 6;
            this.linkLabel3.TabStop = true;
            this.linkLabel3.Text = "Yahoo Messenger: xeko_necromancer";
            this.linkLabel3.UseCompatibleTextRendering = true;
            this.linkLabel3.VisitedLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(131)))), ((int)(((byte)(244)))));
            // 
            // linkLabel4
            // 
            this.linkLabel4.AutoSize = true;
            this.linkLabel4.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.linkLabel4.LinkArea = new System.Windows.Forms.LinkArea(7, 23);
            this.linkLabel4.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.linkLabel4.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(131)))), ((int)(((byte)(244)))));
            this.linkLabel4.Location = new System.Drawing.Point(48, 205);
            this.linkLabel4.Name = "linkLabel4";
            this.linkLabel4.Size = new System.Drawing.Size(156, 23);
            this.linkLabel4.TabIndex = 7;
            this.linkLabel4.TabStop = true;
            this.linkLabel4.Text = "Phone: +84 167 4710360";
            this.linkLabel4.UseCompatibleTextRendering = true;
            this.linkLabel4.VisitedLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(131)))), ((int)(((byte)(244)))));
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Underline);
            this.label2.Location = new System.Drawing.Point(19, 238);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 19);
            this.label2.TabIndex = 8;
            this.label2.Text = "Website: ";
            // 
            // linkLabel5
            // 
            this.linkLabel5.AutoSize = true;
            this.linkLabel5.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.linkLabel5.LinkArea = new System.Windows.Forms.LinkArea(23, 99);
            this.linkLabel5.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.linkLabel5.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(131)))), ((int)(((byte)(244)))));
            this.linkLabel5.Location = new System.Drawing.Point(48, 264);
            this.linkLabel5.Name = "linkLabel5";
            this.linkLabel5.Size = new System.Drawing.Size(380, 23);
            this.linkLabel5.TabIndex = 9;
            this.linkLabel5.TabStop = true;
            this.linkLabel5.Text = "PhapSoftware homepage: http://phapsoftware.wordpress.com";
            this.linkLabel5.UseCompatibleTextRendering = true;
            this.linkLabel5.VisitedLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(131)))), ((int)(((byte)(244)))));
            // 
            // linkLabel6
            // 
            this.linkLabel6.AutoSize = true;
            this.linkLabel6.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.linkLabel6.LinkArea = new System.Windows.Forms.LinkArea(21, 99);
            this.linkLabel6.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.linkLabel6.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(131)))), ((int)(((byte)(244)))));
            this.linkLabel6.Location = new System.Drawing.Point(48, 287);
            this.linkLabel6.Name = "linkLabel6";
            this.linkLabel6.Size = new System.Drawing.Size(280, 23);
            this.linkLabel6.TabIndex = 10;
            this.linkLabel6.TabStop = true;
            this.linkLabel6.Text = "ImageGlass homepage: http://imageglass.org";
            this.linkLabel6.UseCompatibleTextRendering = true;
            this.linkLabel6.VisitedLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(131)))), ((int)(((byte)(244)))));
            // 
            // linkLabel7
            // 
            this.linkLabel7.AutoSize = true;
            this.linkLabel7.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.linkLabel7.LinkArea = new System.Windows.Forms.LinkArea(10, 99);
            this.linkLabel7.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.linkLabel7.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(131)))), ((int)(((byte)(244)))));
            this.linkLabel7.Location = new System.Drawing.Point(48, 310);
            this.linkLabel7.Name = "linkLabel7";
            this.linkLabel7.Size = new System.Drawing.Size(267, 23);
            this.linkLabel7.TabIndex = 11;
            this.linkLabel7.TabStop = true;
            this.linkLabel7.Text = "Mã nguồn: http://imageglass.codeplex.com";
            this.linkLabel7.UseCompatibleTextRendering = true;
            this.linkLabel7.VisitedLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(131)))), ((int)(((byte)(244)))));
            // 
            // linkLabel8
            // 
            this.linkLabel8.AutoSize = true;
            this.linkLabel8.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.linkLabel8.LinkArea = new System.Windows.Forms.LinkArea(10, 99);
            this.linkLabel8.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.linkLabel8.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(131)))), ((int)(((byte)(244)))));
            this.linkLabel8.Location = new System.Drawing.Point(48, 333);
            this.linkLabel8.Name = "linkLabel8";
            this.linkLabel8.Size = new System.Drawing.Size(267, 23);
            this.linkLabel8.TabIndex = 12;
            this.linkLabel8.TabStop = true;
            this.linkLabel8.Text = "Facebook: http://facebook.com/imageglass";
            this.linkLabel8.UseCompatibleTextRendering = true;
            this.linkLabel8.VisitedLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(131)))), ((int)(((byte)(244)))));
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Underline);
            this.label3.Location = new System.Drawing.Point(19, 366);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(138, 19);
            this.label3.TabIndex = 13;
            this.label3.Text = "Cập nhật phần mềm:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.label4.Location = new System.Drawing.Point(44, 393);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(283, 19);
            this.label4.TabIndex = 14;
            this.label4.Text = "Lần kiểm tra gần nhất: 23/12/2011 08:30:20";
            // 
            // linkLabel9
            // 
            this.linkLabel9.AutoSize = true;
            this.linkLabel9.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.linkLabel9.LinkArea = new System.Windows.Forms.LinkArea(0, 99);
            this.linkLabel9.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.linkLabel9.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(131)))), ((int)(((byte)(244)))));
            this.linkLabel9.Location = new System.Drawing.Point(48, 412);
            this.linkLabel9.Name = "linkLabel9";
            this.linkLabel9.Size = new System.Drawing.Size(158, 23);
            this.linkLabel9.TabIndex = 15;
            this.linkLabel9.TabStop = true;
            this.linkLabel9.Text = "» Kiểm tra phiên bản mới";
            this.linkLabel9.UseCompatibleTextRendering = true;
            this.linkLabel9.VisitedLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(131)))), ((int)(((byte)(244)))));
            // 
            // frmAbout
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(746, 474);
            this.Controls.Add(this.panAbout);
            this.Controls.Add(this.lblDonate);
            this.Controls.Add(this.lblLink);
            this.Controls.Add(this.lblComponent);
            this.Controls.Add(this.lblAbout);
            this.Controls.Add(this.pictureBox1);
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "frmAbout";
            this.Text = "About";
            this.Load += new System.EventHandler(this.frmAbout_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panAbout.ResumeLayout(false);
            this.panAbout.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblAbout;
        private System.Windows.Forms.Label lblComponent;
        private System.Windows.Forms.Label lblLink;
        private System.Windows.Forms.Label lblDonate;
        private System.Windows.Forms.Panel panAbout;
        private System.Windows.Forms.Label lblCopyright;
        private System.Windows.Forms.Label lblVersion;
        private System.Windows.Forms.LinkLabel linkLabel3;
        private System.Windows.Forms.LinkLabel linkLabel2;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.LinkLabel linkLabel4;
        private System.Windows.Forms.LinkLabel linkLabel5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.LinkLabel linkLabel6;
        private System.Windows.Forms.LinkLabel linkLabel7;
        private System.Windows.Forms.LinkLabel linkLabel8;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.LinkLabel linkLabel9;
    }
}