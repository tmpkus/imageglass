﻿/*
ImageGlass Project - Image viewer for Windows
Copyright (C) 2012 DUONG DIEU PHAP
Project homepage: http://imageglass.codeplex.com

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ImageGlass
{
    public partial class frmAbout : Form
    {
        public frmAbout()
        {
            InitializeComponent();
        }

        private void lblDonate_MouseDown(object sender, MouseEventArgs e)
        {
            Label lbl = (Label)sender;
            lbl.BackColor = Color.FromArgb(170, 0, 138, 232);
        }

        private void lblDonate_MouseUp(object sender, MouseEventArgs e)
        {
            Label lbl = (Label)sender;

            if (int.Parse(lbl.Tag.ToString()) == 1)
            {
                lbl.BackColor = Color.FromArgb(100, 0, 138, 232);
            }
            else
            {
                lbl.BackColor = Color.FromArgb(10, 255, 255, 255);
            }

        }

        private void lblDonate_Click(object sender, EventArgs e)
        {
            Label lbl = (Label)sender;

            lblAbout.Tag = 0;
            lblComponent.Tag = 0;
            lblLink.Tag = 0;
            lblDonate.Tag = 0;

            lblAbout.BackColor = Color.FromArgb(0, 0, 138, 232);
            lblComponent.BackColor = Color.FromArgb(0, 0, 138, 232);
            lblLink.BackColor = Color.FromArgb(0, 0, 138, 232);
            lblDonate.BackColor = Color.FromArgb(0, 0, 138, 232);
            
            lbl.Tag = 1;
            lbl.BackColor = Color.FromArgb(170, 0, 138, 232);

        }

        private void lblDonate_MouseEnter(object sender, EventArgs e)
        {
            Label lbl = (Label)sender;

            if (int.Parse(lbl.Tag.ToString()) == 1)
            {
                lbl.BackColor = Color.FromArgb(100, 0, 138, 232);
            }
            else
            {
                lbl.BackColor = Color.FromArgb(10, 255, 255, 255);
            }

        }

        private void lblDonate_MouseLeave(object sender, EventArgs e)
        {
            Label lbl = (Label)sender;
            if (int.Parse(lbl.Tag.ToString()) == 1)
            {
                lbl.BackColor = Color.FromArgb(170, 0, 138, 232);
            }
            else
            {
                lbl.BackColor = Color.FromArgb(0, 0, 138, 232);
            }
        }

        private void frmAbout_Load(object sender, EventArgs e)
        {
            lblVersion.Text = "Phiên bản: " + Application.ProductVersion;
        }
    }
}
