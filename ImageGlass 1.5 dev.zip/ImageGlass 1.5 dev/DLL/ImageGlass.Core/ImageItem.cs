﻿/*
ImageGlass Project - Image viewer for Windows
Copyright (C) 2012 DUONG DIEU PHAP
Project homepage: http://imageglass.codeplex.com

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;

namespace ImageGlass.Core
{
    public class ImageItem
    {

        private Image _img;
        private string _path;
        private bool _isFinished;
        private bool _isFailed;


        #region Properties
        /// <summary>
        /// Get image
        /// </summary>
        public Image Image
        {
            get { return _img; }
        }

        public string Path
        {
            get { return _path; }
        }

        public bool IsFinished
        {
            get { return _isFinished; }
        }

        public bool IsFailed
        {
            get { return _isFailed; }
        }
        #endregion


        #region Method
        /// <summary>
        /// New image
        /// </summary>
        /// <param name="filename">Path of image</param>
        public ImageItem(string filename)
        {
            this._path = filename;
            this.Dispose();
        }

        /// <summary>
        /// Release all resources and set to default
        /// </summary>
        public void Dispose()
        {
            if (_img != null)
            {
                _img.Dispose();
                _img = null;
            }
            _isFailed = false;
            _isFinished = false;
        }

        /// <summary>
        /// Load image to memory
        /// </summary>
        public void LoadImage()
        {
            //Set all config to default
            this.Dispose();
            Image im = null;

            //Start load image
            try
            {
                im = new Bitmap(_path);
            }
            catch { }


            if (im != null)
            {
                _isFailed = false;
                _img = im;
            }
            //If image is invalid, show error
            else
            {
                _isFailed = true;
                _img = ImageGlass.Core.Properties.Resources.Image_Error;
            }
            _isFinished = true;
        }
        #endregion


    }
}
