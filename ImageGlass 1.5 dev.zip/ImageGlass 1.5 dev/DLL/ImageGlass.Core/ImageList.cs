﻿/*
ImageGlass Project - Image viewer for Windows
Copyright (C) 2012 DUONG DIEU PHAP
Project homepage: http://imageglass.codeplex.com

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading;

namespace ImageGlass.Core
{
    public class ImageList
    {

        private List<ImageItem> _items;       
        private List<ImageItem> _queue;
        private bool _isBoostLoading;

        #region Property Function
        /// <summary>
        /// Get Image item
        /// </summary>
        public List<ImageItem> Items
        {
            get { return _items; }
        } 

        /// <summary>
        /// Get, Set value to boost image loading
        /// </summary>
        public bool IsBoostLoading
        {
            get { return _isBoostLoading; }
            set { _isBoostLoading = value; }
        }

        /// <summary>
        /// Get total image in list
        /// </summary>
        /// <returns></returns>
        public int GetTotalImage()
        {
            return _items.Count;
        }

        /// <summary>
        /// Get image filename
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        public string GetImageFileName(int index)
        {
            return _items[index].Path;
        }

        /// <summary>
        /// Unload image and release all resources
        /// </summary>
        /// <param name="index"></param>
        public void UnloadImage(int index)
        {
            _items[index].Dispose();
        }

        /// <summary>
        /// Remove an image
        /// </summary>
        /// <param name="index"></param>
        public void RemoveImageItem(int index)
        {
            UnloadImage(index);
            _items.RemoveAt(index);
        }

        /// <summary>
        /// Release all resources
        /// </summary>
        public void Dispose()
        {
            //Remove & release all resources
            for (int i = 0; i < _items.Count; i++)
            {
                RemoveImageItem(i);
            }

            _items.Clear();
            _queue.Clear();
        }
#endregion


        public ImageList()
        {
            _items = new List<ImageItem>();
            _queue = new List<ImageItem>();
            _isBoostLoading = true;
        }

        public ImageList(string[] imgFiles)
        {
            _items = new List<ImageItem>();
            _queue = new List<ImageItem>();
            _isBoostLoading = true;

            //add all item to list
            for (int i = 0; i < imgFiles.Length; i++)
            {
                _items.Add(new ImageItem(imgFiles[i]));
            }

            //Start loading
            Thread tLoad = new Thread(new ThreadStart(StartLoading));
            tLoad.Priority = ThreadPriority.BelowNormal;
            tLoad.IsBackground = true;
            tLoad.Start();

        }

        /// <summary>
        /// Start loading image to memory
        /// </summary>
        private void StartLoading()
        {
            while (true)
            {
                //If queue is not empty
                if (_queue.Count > 0)
                {
                    //Dequeue image
                    ImageItem im = _queue[0];
                    _queue.RemoveAt(0);

                    //Load dequeued image
                    if (im.IsFinished == false)
                    {
                        im.LoadImage();
                    }
                }
                    //If queue is empty
                else
                {
                    //Waiting for 10 ms
                    Thread.Sleep(10);
                }
            
            }
        }

        /// <summary>
        /// Add image to queue
        /// </summary>
        /// <param name="i"></param>
        private void Enqueue(int i)
        {
            //If i is invalid
            if (i < 0 || i >= _items.Count) return;

            //If image is not loaded
            if(_items[i].IsFinished == false)
            {
                //Add to queue
                _queue.Add(_items[i]);
            }
        }

        /// <summary>
        /// Get image
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        public System.Drawing.Image GetImage(int index)
        {
            for (int i = 0; i < _items.Count; i++)
            {
                _items[i].Dispose();
                //if (i == index || i == index + 1 || i == index - 1)
                //{

                //}
                //else
                //{
                //    _items[i].Dispose();
                //}            
            }


            //Empty queue
            _queue.Clear();
            
            //Add current image index
            ImageItem ii = _items[index];
            _queue.Add(ii);

            //Pre-load image
            Enqueue(index + 1);
            Enqueue(index - 1);

            while (_items[index].IsFinished == false)
            {
                Thread.Sleep(5);
            }

            //Return true image
            if (_items[index].IsFailed == false)
            {
                return _items[index].Image;
            }
                //Return error image
            else
            {
                return ImageGlass.Core.Properties.Resources.Image_Error;
            }

        }

        /// <summary>
        /// Get error image
        /// </summary>
        /// <returns></returns>
        public System.Drawing.Bitmap GetErrorImage()
        {
            return ImageGlass.Core.Properties.Resources.Image_Error;
        }
    

    }
}
