﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;

namespace ImageGlass
{
    public class RenderTheme
    {
        [DllImport("uxtheme.dll")]
        public static extern int SetWindowTheme(
            [In] IntPtr hwnd,
            [In, MarshalAs(UnmanagedType.LPWStr)] string pszSubAppName,
            [In, MarshalAs(UnmanagedType.LPWStr)] string pszSubIdList
            );


        public int ApplyTheme(System.Windows.Forms.Control control)
        {
            return this.ApplyTheme(control, "Explorer");
        }

        public int ApplyTheme(System.Windows.Forms.Control control, string theme)
        {
            try
            {
                if (control != null)
                {
                    if (control.IsHandleCreated)
                    {
                        return SetWindowTheme(control.Handle, theme, null);
                    }
                }
            }
            catch
            {
                return 0;
            }
            return 1;
        }

        public int ClearTheme(System.Windows.Forms.Control control)
        {
            return this.ApplyTheme(control, string.Empty);
        }

    }
}
