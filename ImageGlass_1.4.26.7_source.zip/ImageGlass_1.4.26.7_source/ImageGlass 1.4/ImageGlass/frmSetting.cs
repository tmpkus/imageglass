﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ImageGlass
{
    public partial class frmSetting : Form
    {
        public frmSetting()
        {
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Global.Plugins.ClosePlugins();
            this.Close();
        }

        private void frmSetting_Load(object sender, EventArgs e)
        {
            RenderTheme r = new RenderTheme();
            r.ApplyTheme(tvFeature);
            Global.Plugins.FindPlugins(Application.StartupPath + @"\Plugins");

            foreach (Types.AvailablePlugin p in Global.Plugins.AvailablePlugins)
            {
                TreeNode n = new TreeNode(p.Instance.Name);
                tvFeature.Nodes.Add(n);
                n = null;
            }            
        }

        private void tvFeature_AfterSelect(object sender, TreeViewEventArgs e)
        {
            if (tvFeature.SelectedNode != null)
            {
                Types.AvailablePlugin p = Global.Plugins.AvailablePlugins.Find(
                                          tvFeature.SelectedNode.Text);
                if (p != null)
                {
                    panMain.Controls.Clear();
                    p.Instance.MainInterface.Dock = DockStyle.Fill;
                    panMain.Controls.Add(p.Instance.MainInterface);
                }

            }
        }
    }
}
