﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using ImageGlass.Feature;
using System.IO;
using System.Diagnostics;

namespace ImageGlass
{
    public partial class frmAbout : Form
    {
        public frmAbout()
        {
            InitializeComponent();
        }

        private void btnCheckForUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                Process.Start(char.ConvertFromUtf32(34) +
                                (Application.StartupPath + "\\").Replace("\\\\", "\\") + "igcmd.exe" +
                                char.ConvertFromUtf32(34), "igupdate");
            }
            catch { }
        }

        private void lnkProject_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("https://sites.google.com/site/psimageglass/");
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmAbout_Load(object sender, EventArgs e)
        {
            
            lblVersion.Text = "Version: " + Application.ProductVersion;
        }

        private void lnkSupport_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("https://sites.google.com/site/psimageglass/donate");
        }

        private void lnkEmail_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("mailto:d2phap@gmail.com");
        }

        private void lnkHomepage_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("http://phapsoftware.wordpress.com");
        }

        private void picIGSite_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start(((PictureBox)sender).Tag.ToString());
        }

        private void lnkIGSite_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start(((LinkLabel)sender).Tag.ToString());
        }

        private void tab1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (tab1.SelectedIndex == 1)//version
            {
                RenderTheme r = new RenderTheme();
                r.ApplyTheme(lv);

                lv.Items.Clear();
                string dir = (Path.GetDirectoryName(Application.ExecutablePath) + "\\").Replace("\\\\", "\\");

                FileVersionInfo f = FileVersionInfo.GetVersionInfo(Application.ExecutablePath);
                ListViewItem i = lv.Items.Add(f.ProductName);
                i.SubItems.Add(f.FileVersion);
                i.SubItems.Add(f.FileName);

                f = FileVersionInfo.GetVersionInfo(dir + "ImageGlass.Core.dll");
                i = lv.Items.Add(f.ProductName);
                i.SubItems.Add(f.FileVersion);
                i.SubItems.Add(f.FileName);

                f = FileVersionInfo.GetVersionInfo(dir + "ImageGlass.Feature.dll");
                i = lv.Items.Add(f.ProductName);
                i.SubItems.Add(f.FileVersion);
                i.SubItems.Add(f.FileName);

                f = FileVersionInfo.GetVersionInfo(dir + "ImageGlass.Theme.dll");
                i = lv.Items.Add(f.ProductName);
                i.SubItems.Add(f.FileVersion);
                i.SubItems.Add(f.FileName);

                f = FileVersionInfo.GetVersionInfo(dir + "PluginInterface.dll");
                i = lv.Items.Add(f.ProductName);
                i.SubItems.Add(f.FileVersion);
                i.SubItems.Add(f.FileName);

                f = FileVersionInfo.GetVersionInfo(dir + "Ionic.Zip.dll");
                i = lv.Items.Add(f.ProductName);
                i.SubItems.Add(f.FileVersion);
                i.SubItems.Add(f.FileName);

                f = FileVersionInfo.GetVersionInfo(dir + "igcmd.exe");
                i = lv.Items.Add(f.ProductName);
                i.SubItems.Add(f.FileVersion);
                i.SubItems.Add(f.FileName);

                if (Directory.Exists(dir + "Plugins\\"))
                {
                    foreach (string fi in Directory.GetFiles(dir + "Plugins\\"))
                    {
                        if (Path.GetExtension(fi).ToLower() == ".dll")
                        {
                            f = FileVersionInfo.GetVersionInfo(fi);
                            i = lv.Items.Add(f.ProductName);
                            i.SubItems.Add(f.FileVersion);
                            i.SubItems.Add(f.FileName);
                        }
                    }
                }

            }



        }

       
     

       
    }
}
