﻿namespace ImageGlass
{
    partial class frmAbout
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmAbout));
            this.lnkProject = new System.Windows.Forms.LinkLabel();
            this.label8 = new System.Windows.Forms.Label();
            this.lnkSupport = new System.Windows.Forms.LinkLabel();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.lnkPS = new System.Windows.Forms.LinkLabel();
            this.lnkFB = new System.Windows.Forms.LinkLabel();
            this.lnkIGSite = new System.Windows.Forms.LinkLabel();
            this.picPS = new System.Windows.Forms.PictureBox();
            this.picIGSite = new System.Windows.Forms.PictureBox();
            this.picFB = new System.Windows.Forms.PictureBox();
            this.btnClose = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tab1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.lnkEmail = new System.Windows.Forms.LinkLabel();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblVersion = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lnkHomepage = new System.Windows.Forms.LinkLabel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnCheckForUpdate = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.lv = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picPS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picIGSite)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picFB)).BeginInit();
            this.tab1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.SuspendLayout();
            // 
            // lnkProject
            // 
            this.lnkProject.AutoSize = true;
            this.lnkProject.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.lnkProject.LinkArea = new System.Windows.Forms.LinkArea(17, 59);
            this.lnkProject.Location = new System.Drawing.Point(19, 189);
            this.lnkProject.Name = "lnkProject";
            this.lnkProject.Size = new System.Drawing.Size(400, 23);
            this.lnkProject.TabIndex = 6;
            this.lnkProject.TabStop = true;
            this.lnkProject.Text = "ImageGlass Site: https://sites.google.com/site/psimageglass/";
            this.lnkProject.UseCompatibleTextRendering = true;
            this.lnkProject.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkProject_LinkClicked);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.label8.Location = new System.Drawing.Point(17, 160);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(401, 19);
            this.label8.TabIndex = 5;
            this.label8.Text = "Yahoo Messenger, Windows Live Messenger: xeko_necromancer";
            // 
            // lnkSupport
            // 
            this.lnkSupport.AutoSize = true;
            this.lnkSupport.BackColor = System.Drawing.Color.Transparent;
            this.lnkSupport.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnkSupport.LinkArea = new System.Windows.Forms.LinkArea(7, 7);
            this.lnkSupport.Location = new System.Drawing.Point(12, 24);
            this.lnkSupport.Name = "lnkSupport";
            this.lnkSupport.Size = new System.Drawing.Size(264, 21);
            this.lnkSupport.TabIndex = 16;
            this.lnkSupport.TabStop = true;
            this.lnkSupport.Text = "Please support this project to have more features";
            this.lnkSupport.UseCompatibleTextRendering = true;
            this.lnkSupport.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkSupport_LinkClicked);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.lnkPS);
            this.tabPage3.Controls.Add(this.lnkFB);
            this.tabPage3.Controls.Add(this.lnkIGSite);
            this.tabPage3.Controls.Add(this.picPS);
            this.tabPage3.Controls.Add(this.picIGSite);
            this.tabPage3.Controls.Add(this.picFB);
            this.tabPage3.Location = new System.Drawing.Point(4, 24);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(541, 220);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "ImageGlass online";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // lnkPS
            // 
            this.lnkPS.AutoSize = true;
            this.lnkPS.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.lnkPS.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.lnkPS.Location = new System.Drawing.Point(376, 135);
            this.lnkPS.Name = "lnkPS";
            this.lnkPS.Size = new System.Drawing.Size(122, 25);
            this.lnkPS.TabIndex = 9;
            this.lnkPS.TabStop = true;
            this.lnkPS.Tag = "http://phapsoftware.wordpress.com";
            this.lnkPS.Text = "PhapSoftware";
            this.lnkPS.Click += new System.EventHandler(this.lnkIGSite_Click);
            // 
            // lnkFB
            // 
            this.lnkFB.AutoSize = true;
            this.lnkFB.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.lnkFB.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.lnkFB.Location = new System.Drawing.Point(228, 135);
            this.lnkFB.Name = "lnkFB";
            this.lnkFB.Size = new System.Drawing.Size(89, 25);
            this.lnkFB.TabIndex = 8;
            this.lnkFB.TabStop = true;
            this.lnkFB.Tag = "http://www.facebook.com/pages/ImageGlass/219891608051327";
            this.lnkFB.Text = "Facebook";
            this.lnkFB.Click += new System.EventHandler(this.lnkIGSite_Click);
            // 
            // lnkIGSite
            // 
            this.lnkIGSite.AutoSize = true;
            this.lnkIGSite.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.lnkIGSite.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.lnkIGSite.Location = new System.Drawing.Point(36, 135);
            this.lnkIGSite.Name = "lnkIGSite";
            this.lnkIGSite.Size = new System.Drawing.Size(135, 25);
            this.lnkIGSite.TabIndex = 7;
            this.lnkIGSite.TabStop = true;
            this.lnkIGSite.Tag = "https://sites.google.com/site/psimageglass/";
            this.lnkIGSite.Text = "ImageGlass site";
            this.lnkIGSite.Click += new System.EventHandler(this.lnkIGSite_Click);
            // 
            // picPS
            // 
            this.picPS.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picPS.Image = ((System.Drawing.Image)(resources.GetObject("picPS.Image")));
            this.picPS.Location = new System.Drawing.Point(385, 32);
            this.picPS.Name = "picPS";
            this.picPS.Size = new System.Drawing.Size(100, 100);
            this.picPS.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.picPS.TabIndex = 5;
            this.picPS.TabStop = false;
            this.picPS.Tag = "http://phapsoftware.wordpress.com";
            this.picPS.Click += new System.EventHandler(this.picIGSite_Click);
            // 
            // picIGSite
            // 
            this.picIGSite.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picIGSite.Image = ((System.Drawing.Image)(resources.GetObject("picIGSite.Image")));
            this.picIGSite.Location = new System.Drawing.Point(54, 32);
            this.picIGSite.Name = "picIGSite";
            this.picIGSite.Size = new System.Drawing.Size(100, 100);
            this.picIGSite.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.picIGSite.TabIndex = 1;
            this.picIGSite.TabStop = false;
            this.picIGSite.Tag = "https://sites.google.com/site/psimageglass/";
            this.picIGSite.Click += new System.EventHandler(this.picIGSite_Click);
            // 
            // picFB
            // 
            this.picFB.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picFB.Image = ((System.Drawing.Image)(resources.GetObject("picFB.Image")));
            this.picFB.Location = new System.Drawing.Point(221, 32);
            this.picFB.Name = "picFB";
            this.picFB.Size = new System.Drawing.Size(100, 100);
            this.picFB.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.picFB.TabIndex = 0;
            this.picFB.TabStop = false;
            this.picFB.Tag = "http://www.facebook.com/pages/ImageGlass/219891608051327";
            this.picFB.Click += new System.EventHandler(this.picIGSite_Click);
            // 
            // btnClose
            // 
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClose.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnClose.Location = new System.Drawing.Point(482, 16);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 30);
            this.btnClose.TabIndex = 14;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.label5.Location = new System.Drawing.Point(17, 71);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(300, 38);
            this.label5.TabIndex = 2;
            this.label5.Text = "Copyright © 2010 - 2011 by Duong Dieu Phap\r\nAll rights reserved";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 25F);
            this.label1.Location = new System.Drawing.Point(146, 68);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(189, 46);
            this.label1.TabIndex = 11;
            this.label1.Text = "ImageGlass";
            // 
            // tab1
            // 
            this.tab1.Controls.Add(this.tabPage1);
            this.tab1.Controls.Add(this.tabPage2);
            this.tab1.Controls.Add(this.tabPage3);
            this.tab1.Location = new System.Drawing.Point(12, 144);
            this.tab1.Name = "tab1";
            this.tab1.SelectedIndex = 0;
            this.tab1.Size = new System.Drawing.Size(549, 248);
            this.tab1.TabIndex = 13;
            this.tab1.SelectedIndexChanged += new System.EventHandler(this.tab1_SelectedIndexChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.lnkEmail);
            this.tabPage1.Controls.Add(this.lnkProject);
            this.tabPage1.Controls.Add(this.label8);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.lblVersion);
            this.tabPage1.Location = new System.Drawing.Point(4, 24);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(541, 220);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "About";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // lnkEmail
            // 
            this.lnkEmail.AutoSize = true;
            this.lnkEmail.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lnkEmail.LinkArea = new System.Windows.Forms.LinkArea(7, 59);
            this.lnkEmail.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.lnkEmail.Location = new System.Drawing.Point(22, 141);
            this.lnkEmail.Name = "lnkEmail";
            this.lnkEmail.Size = new System.Drawing.Size(166, 23);
            this.lnkEmail.TabIndex = 7;
            this.lnkEmail.TabStop = true;
            this.lnkEmail.Text = "Email: d2phap@gmail.com";
            this.lnkEmail.UseCompatibleTextRendering = true;
            this.lnkEmail.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkEmail_LinkClicked);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.label6.Location = new System.Drawing.Point(17, 122);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(165, 19);
            this.label6.TabIndex = 3;
            this.label6.Text = "Phone: +84167 4710360";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.label4.Location = new System.Drawing.Point(17, 47);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(168, 19);
            this.label4.TabIndex = 1;
            this.label4.Text = "Author: Duong Dieu Phap";
            // 
            // lblVersion
            // 
            this.lblVersion.AutoSize = true;
            this.lblVersion.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblVersion.Location = new System.Drawing.Point(17, 16);
            this.lblVersion.Name = "lblVersion";
            this.lblVersion.Size = new System.Drawing.Size(70, 19);
            this.lblVersion.TabIndex = 0;
            this.lblVersion.Text = "Version: #";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.label2.Location = new System.Drawing.Point(150, 111);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(171, 19);
            this.label2.TabIndex = 12;
            this.label2.Text = "Image viewer for Windows";
            // 
            // lnkHomepage
            // 
            this.lnkHomepage.AutoSize = true;
            this.lnkHomepage.BackColor = System.Drawing.Color.Transparent;
            this.lnkHomepage.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnkHomepage.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.lnkHomepage.Location = new System.Drawing.Point(358, 116);
            this.lnkHomepage.Name = "lnkHomepage";
            this.lnkHomepage.Size = new System.Drawing.Size(204, 17);
            this.lnkHomepage.TabIndex = 17;
            this.lnkHomepage.TabStop = true;
            this.lnkHomepage.Text = "http://phapsoftware.wordpress.com";
            this.lnkHomepage.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkHomepage_LinkClicked);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 10);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(128, 128);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 10;
            this.pictureBox1.TabStop = false;
            // 
            // btnCheckForUpdate
            // 
            this.btnCheckForUpdate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCheckForUpdate.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCheckForUpdate.Image = ((System.Drawing.Image)(resources.GetObject("btnCheckForUpdate.Image")));
            this.btnCheckForUpdate.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCheckForUpdate.Location = new System.Drawing.Point(350, 16);
            this.btnCheckForUpdate.Name = "btnCheckForUpdate";
            this.btnCheckForUpdate.Size = new System.Drawing.Size(126, 30);
            this.btnCheckForUpdate.TabIndex = 15;
            this.btnCheckForUpdate.Text = "Check for update";
            this.btnCheckForUpdate.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnCheckForUpdate.UseVisualStyleBackColor = true;
            this.btnCheckForUpdate.Click += new System.EventHandler(this.btnCheckForUpdate_Click);
            // 
            // panel1
            // 
            this.panel1.BackgroundImage = global::ImageGlass.Properties.Resources.bottombar;
            this.panel1.Controls.Add(this.btnClose);
            this.panel1.Controls.Add(this.btnCheckForUpdate);
            this.panel1.Controls.Add(this.lnkSupport);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 404);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(574, 58);
            this.panel1.TabIndex = 18;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.lv);
            this.tabPage2.Location = new System.Drawing.Point(4, 24);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Size = new System.Drawing.Size(541, 220);
            this.tabPage2.TabIndex = 3;
            this.tabPage2.Text = "Components";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // lv
            // 
            this.lv.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lv.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3});
            this.lv.FullRowSelect = true;
            this.lv.Location = new System.Drawing.Point(14, 15);
            this.lv.Name = "lv";
            this.lv.Size = new System.Drawing.Size(511, 191);
            this.lv.TabIndex = 0;
            this.lv.UseCompatibleStateImageBehavior = false;
            this.lv.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Component";
            this.columnHeader1.Width = 180;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Version";
            this.columnHeader2.Width = 80;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Path";
            this.columnHeader3.Width = 240;
            // 
            // frmAbout
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.CancelButton = this.btnClose;
            this.ClientSize = new System.Drawing.Size(574, 462);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tab1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lnkHomepage);
            this.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(590, 500);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(590, 500);
            this.Name = "frmAbout";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "About ImageGlass";
            this.Load += new System.EventHandler(this.frmAbout_Load);
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picPS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picIGSite)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picFB)).EndInit();
            this.tab1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.LinkLabel lnkProject;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.LinkLabel lnkSupport;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Button btnCheckForUpdate;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabControl tab1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblVersion;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.LinkLabel lnkHomepage;
        private System.Windows.Forms.LinkLabel lnkEmail;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox picIGSite;
        private System.Windows.Forms.PictureBox picFB;
        private System.Windows.Forms.PictureBox picPS;
        private System.Windows.Forms.LinkLabel lnkPS;
        private System.Windows.Forms.LinkLabel lnkFB;
        private System.Windows.Forms.LinkLabel lnkIGSite;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.ListView lv;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
    }
}