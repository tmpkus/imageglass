﻿/*
 * imaeg - generic image utility in C#
 * Copyright (C) 2010  ed <tripflag@gmail.com>
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License v2
 * (version 2) as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, refer to the following URL:
 * http://www.gnu.org/licenses/old-licenses/gpl-2.0.txt
 */
using System;
using System.Collections.Generic;
using System.Windows.Forms;
using Microsoft.Win32;
using System.Diagnostics;
using System.IO;

namespace ImageGlass
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        public static string[] args;
        public static string igPath = (Application.StartupPath + "\\").Replace("\\\\", "\\");
        [STAThread]
        static void Main(string[] argv)
        {            
            args = argv;            
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new frmMain()); 

            //autoupdate--------------------------------------------------------------------------------
            string s = Registry.GetValue(@"HKEY_CURRENT_USER\Software\PhapSoftware\ImageGlass\",
                                    "AutoUpdate", "1").ToString();
            if (s != "0")
            {
                // dd/mm/yyyy
                string d = DateTime.Now.Day.ToString() + "/" + 
                            DateTime.Now.Month.ToString() + "/" + 
                            DateTime.Now.Year.ToString();
                if (d != s)
                {
                    Process.Start(char.ConvertFromUtf32(34) +
                                Program.igPath + "igcmd.exe" +
                                char.ConvertFromUtf32(34), "igautoupdate");
                }

            }

            //dang ky ext *.igtheme---------------------------------------------------------------------
            Registry.SetValue("HKEY_CLASSES_ROOT\\.igtheme\\", "", "ImageGlass.igtheme");
            Registry.SetValue("HKEY_CLASSES_ROOT\\ImageGlass.igtheme\\", "", "ImageGlass theme");
            //icon
            Registry.SetValue("HKEY_CLASSES_ROOT\\ImageGlass.igtheme\\DefaultIcon\\", "",
                char.ConvertFromUtf32(34) + Program.igPath + "igcmd.exe" + char.ConvertFromUtf32(34) +
                ",0");

            Registry.SetValue("HKEY_CLASSES_ROOT\\ImageGlass.igtheme\\shell\\open\\command\\", "",
                char.ConvertFromUtf32(34) + Program.igPath + "igcmd.exe" + char.ConvertFromUtf32(34) +
                " iginstalltheme " + char.ConvertFromUtf32(34) + "%1" + char.ConvertFromUtf32(34));

            //xoa thu muc Temp---------------------------------------------------------------------------
            if (Directory.Exists(igPath + "Temp"))
            {
                try
                {
                    Directory.Delete(igPath + "Temp", true);
                }
                catch { }
            }

        }
    }
}
