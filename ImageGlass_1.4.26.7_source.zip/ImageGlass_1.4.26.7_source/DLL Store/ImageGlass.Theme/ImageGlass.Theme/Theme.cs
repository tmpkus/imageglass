﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.IO;
using System.Drawing;

namespace ImageGlass.Theme
{
    public class Theme
    {
        //Metadata
        public string name = string.Empty;                     //tên của theme
        public string version = string.Empty;                  //phiên bản của theme
        public string author = string.Empty;                   //tác giả
        public string email = string.Empty;                    //email
        public string website = string.Empty;                  //website
        public string description = string.Empty;              //miêu tả
        public string type = string.Empty;                     //loại tập tin thiết lập
        public string compatibility = string.Empty;            //yêu cầu tương thích với phiên bản thấp nhất
        public string preview = string.Empty;                  //ảnh thu nhỏ của theme

        //main
        public string topbar = string.Empty;                   //ảnh nền thanh công cụ
        public int topbartransparent = 0;                      //0 - không aero glass, 1 - có aero glass
        public Color backcolor = Color.White;                  //màu nền vùng xem ảnh
        public string bottombar = string.Empty;                //ảnh nền thanh thumbnail
        public Color statuscolor = Color.Black;                //màu chữ của thông tin hình ảnh

        //toolbar icon
        public string back = string.Empty;
        public string next = string.Empty;
        public string leftrotate = string.Empty;
        public string rightrotate = string.Empty;
        public string zoomin = string.Empty;
        public string zoomout = string.Empty;
        public string scaletofit = string.Empty;
        public string scaletowidth = string.Empty;
        public string scaletoheight = string.Empty;
        public string autosizewindow = string.Empty;
        public string open = string.Empty;
        public string refresh = string.Empty;
        public string gotoimage = string.Empty;
        public string thumbnail = string.Empty;
        public string caro = string.Empty;
        public string fullscreen = string.Empty;
        public string slideshow = string.Empty;
        public string convert = string.Empty;
        public string settings = string.Empty;
        public string about = string.Empty;
        public string like = string.Empty;
        public string dislike = string.Empty;
        public string report = string.Empty;

        public Theme() { }

        /// <summary>
        /// Read theme data from theme configuration file
        /// </summary>
        /// <param name="file"></param>
        public Theme(string file)
        {
            LoadTheme(file);
        }

        /// <summary>
        /// Read theme data from theme configuration file
        /// </summary>
        /// <param name="file"></param>
        public void LoadTheme(string file)
        {
            XmlDocument doc = new XmlDocument();
            doc.Load(file);
            XmlElement root = doc.DocumentElement;

            XmlElement n = (XmlElement)root.SelectNodes("metadata")[0]; //đọc thẻ <metadata>
            try { name = n.GetAttribute("name"); }
            catch { };
            try { version = n.GetAttribute("version"); }
            catch { };
            try { author = n.GetAttribute("author"); }
            catch { };
            try { email = n.GetAttribute("email"); }
            catch { };
            try { website = n.GetAttribute("website"); }
            catch { };
            try { description = n.GetAttribute("description"); }
            catch { };
            try { type = n.GetAttribute("type"); }
            catch { };
            try { compatibility = n.GetAttribute("compatibility"); }
            catch { };
            try { preview = n.GetAttribute("preview"); }
            catch { };

            n = (XmlElement)root.SelectNodes("main")[0]; //đọc thẻ <main>
            try { topbar = n.GetAttribute("topbar"); }
            catch { };
            try { topbartransparent = int.Parse(n.GetAttribute("topbartransparent")); }
            catch { };
            try { backcolor = Color.FromArgb(int.Parse(n.GetAttribute("backcolor"))); }
            catch { };
            try { bottombar = n.GetAttribute("bottombar"); }
            catch { };
            try { statuscolor = Color.FromArgb(int.Parse(n.GetAttribute("statuscolor"))); }
            catch { };

            n = (XmlElement)root.SelectNodes("toolbar_icon")[0]; //đọc thẻ <toolbar_icon>
            try { back = n.GetAttribute("back"); }
            catch { };
            try { next = n.GetAttribute("next"); }
            catch { };
            try { leftrotate = n.GetAttribute("leftrotate"); }
            catch { };
            try { rightrotate = n.GetAttribute("rightrotate"); }
            catch { };
            try { zoomin = n.GetAttribute("zoomin"); }
            catch { };
            try { zoomout = n.GetAttribute("zoomout"); }
            catch { };
            try { scaletofit = n.GetAttribute("scaletofit"); }
            catch { };
            try { scaletowidth = n.GetAttribute("scaletowidth"); }
            catch { };
            try { scaletoheight = n.GetAttribute("scaletoheight"); }
            catch { };
            try { autosizewindow = n.GetAttribute("autosizewindow"); }
            catch { };
            try { open = n.GetAttribute("open"); }
            catch { };
            try { refresh = n.GetAttribute("refresh"); }
            catch { };
            try { gotoimage = n.GetAttribute("gotoimage"); }
            catch { };
            try { thumbnail = n.GetAttribute("thumbnail"); }
            catch { };
            try { caro = n.GetAttribute("caro"); }
            catch { };
            try { fullscreen = n.GetAttribute("fullscreen"); }
            catch { };
            try { slideshow = n.GetAttribute("slideshow"); }
            catch { };
            try { convert = n.GetAttribute("convert"); }
            catch { };
            try { settings = n.GetAttribute("settings"); }
            catch { };
            try { about = n.GetAttribute("about"); }
            catch { };
            try { like = n.GetAttribute("like"); }
            catch { };
            try { dislike = n.GetAttribute("dislike"); }
            catch { };
            try { report = n.GetAttribute("report"); }
            catch { };

        }

    }
}
