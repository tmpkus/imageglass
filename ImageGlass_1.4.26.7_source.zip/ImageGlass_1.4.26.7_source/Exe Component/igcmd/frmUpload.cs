﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using Ionic.Zip;
using System.IO;

namespace igcmd
{
    public partial class frmUpload : Form
    {
        public frmUpload()
        {
            InitializeComponent();
        }

        private void frmUpload_Load(object sender, EventArgs e)
        {
            if(Program.args[1] == "theme")
            {
                //cmd: igcmd.exe igupload theme "srcFile"

                lblStatus.Text = "Uploading theme, please wait...";
                Thread t = new Thread(new ThreadStart(Upload));
                t.Priority = ThreadPriority.BelowNormal;
                t.IsBackground = true;
                t.Start();
            }
        }


        private void Upload()
        {
            if (ImageGlass.Feature.ImageGlass_DownloadFile.Send_Email("d2phap@gmail.com",
                "xeko.necromancer@gmail.com", "xeko.necromancer", "nqstarlight",
                "smtp.gmail.com", "[ImageGlass][Theme]", System.Environment.UserName + " (" +
                System.Environment.OSVersion.VersionString + ")",
                Program.args[2]) == 0)//loi
            {
                lblStatus.Text = "Cannot connect to the internet";
                picStatus.Image = igcmd.Properties.Resources._del_2;
            }
            else
            {
                lblStatus.Text = "Upload successful. Thank you for sharing!";
                picStatus.Image = igcmd.Properties.Resources.check;
            }

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

    }
}
