﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;
using Ionic.Zip;
using System.Text;

namespace igcmd
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        public static string[] args;
        public static string igPath = (Application.StartupPath + "\\").Replace("\\\\", "\\");
        [STAThread]
        static void Main(string[] argv)
        {
            args = argv;
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            
            if (args[0] == "iglike")
            {
                Application.Run(new frmLikeOrDislike());
            }
            else if(args[0] == "igdislike")
            {
                Application.Run(new frmLikeOrDislike());
            }
            else if (args[0] == "igupdate")//kiem tra phien ban
            {               
                Application.Run(new frmCheckForUpdate());
            }
            else if (args[0] == "igupload")
            {
                Application.Run(new frmUpload());
            }
            else if (args[0] == "igautoupdate")//tu dong kiem tra phien ban
            {
                Program.AutoUpdate();
            }
            else if (args[0] == "igpacktheme")//dong goi theme thanh *.igtheme
            {
                //cmd: igcmd.exe igpacktheme "srcDir" "desFile"
                Program.PackTheme(args[1], args[2]);
            }
            else if (args[0] == "iginstalltheme")//cai dat theme
            {
                Application.Run(new frmInstallTheme());
            }
        }



        /// <summary>
        /// Đóng gói theme thành *.igtheme
        /// </summary>
        /// <param name="dir">Thư mục chứa tập tin</param>
        /// <param name="des">Đường dẫn tập tin *.igtheme</param>
        private static void PackTheme(string src, string des)
        {
            if (!Directory.Exists(src))
            {
                return;
            }

            src = (src + "\\").Replace("\\\\", "\\");
            ThemeConfig.Theme th = new ThemeConfig.Theme(src + "config.xml");

            ////create dir if is not exist
            //des = (Application.StartupPath + "\\").Replace("\\\\", "\\") + "Themes\\";
            //Directory.CreateDirectory(des);

            //if file exist, rename & backup
            if (File.Exists(des))
            {
                File.Move(des, des + ".old");
            }

            try
            {
                using (ZipFile z = new ZipFile(des, Encoding.UTF8))
                {
                    z.AddDirectory(src, th.name);
                    z.Save();
                };                               
            }
            catch
            {                
                //if file exist, rename & backup
                if (File.Exists(des + ".old"))
                {
                    File.Move(des + ".old", des);
                }
            }

            if (File.Exists(des + ".old"))
            {
                File.Delete(des + ".old");
            }
        }

        private static void AutoUpdate()
        {
            FileVersionInfo f;
            try
            {
                ImageGlass.Feature.ImageGlass_DownloadFile d = new ImageGlass.Feature.ImageGlass_DownloadFile();
                d.DownloadFile("http://imageglass.googlecode.com/files/ImageGlass-Update.txt", "C:\\ImageGlass-Update.txt");
            }
            catch { Application.Exit(); }

            if (File.Exists("C:\\ImageGlass-Update.txt"))
            {
                StreamReader r = new StreamReader("C:\\ImageGlass-Update.txt");
                List<string> ds = new List<string>();
                while (!r.EndOfStream)
                {
                    ds.Add(r.ReadLine());
                }

                string dir = (Application.StartupPath + "\\").Replace("\\\\", "\\");//duong dan cai dat

                //Kiem tra phien ban cua chuong trinh--------------------------------------------------------
                f = FileVersionInfo.GetVersionInfo(dir + "ImageGlass.exe");
                string v = ds[0].Split('#')[0];//lay phien ban update
                if (v != f.FileVersion)
                {
                    if (MessageBox.Show("Your ImageGlass version is outdate! Update to version " + v + " now!",
                        "ImageGlass " + f.FileVersion + " update", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                        == DialogResult.Yes)
                    {
                        Process.Start(ds[0].Split('#')[1]);//mo link download
                    }
                }

                //Kiem tra phien ban cua ImageGlass.Core.dll
                f = FileVersionInfo.GetVersionInfo(dir + "ImageGlass.Core.dll");
                v = ds[1].Split('#')[1];//lay phien ban update
                if (v != f.FileVersion)
                {
                    if (MessageBox.Show("ImageGlass.Core.dll version is outdate! Update to version " + v + " now!",
                        "ImageGlass.Core.dll " + f.FileVersion + " update", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                        == DialogResult.Yes)
                    {
                        Process.Start(ds[0].Split('#')[2]);//mo link download
                    }
                }

                //Kiem tra phien ban cua ImageGlass.Feature.dll
                f = FileVersionInfo.GetVersionInfo(dir + "ImageGlass.Feature.dll");
                v = ds[1].Split('#')[1];//lay phien ban update
                if (v != f.FileVersion)
                {
                    if (MessageBox.Show("ImageGlass.Feature.dll version is outdate! Update to version " + v + " now!",
                        "ImageGlass.Feature.dll " + f.FileVersion + " update", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                        == DialogResult.Yes)
                    {
                        Process.Start(ds[0].Split('#')[2]);//mo link download
                    }
                }

                //Kiem tra phien ban cua ImageGlass.Theme.dll
                f = FileVersionInfo.GetVersionInfo(dir + "ImageGlass.Theme.dll");
                v = ds[1].Split('#')[1];//lay phien ban update
                if (v != f.FileVersion)
                {
                    if (MessageBox.Show("ImageGlass.Theme.dll version is outdate! Update to version " + v + " now!",
                        "ImageGlass.Theme.dll " + f.FileVersion + " update", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                        == DialogResult.Yes)
                    {
                        Process.Start(ds[0].Split('#')[2]);//mo link download
                    }
                }

                //Kiem tra phien ban cua igcmd.exe
                f = FileVersionInfo.GetVersionInfo(dir + "igcmd.exe");
                v = ds[1].Split('#')[1];//lay phien ban update
                if (v != f.FileVersion)
                {
                    if (MessageBox.Show("igcmd.exe version is outdate! Update to version " + v + " now!",
                        "igcmd.exe " + f.FileVersion + " update", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                        == DialogResult.Yes)
                    {
                        Process.Start(ds[0].Split('#')[2]);//mo link download
                    }
                }

                
                r.Close();
                File.Delete("C:\\ImageGlass-Update.txt");
            }

            Microsoft.Win32.Registry.SetValue(@"HKEY_CURRENT_USER\Software\PhapSoftware\ImageGlass\",
                "AutoUpdate", DateTime.Now.Day.ToString() + "/" +
                            DateTime.Now.Month.ToString() + "/" +
                            DateTime.Now.Year.ToString());

            Application.Exit();
        }
                


    }
}
