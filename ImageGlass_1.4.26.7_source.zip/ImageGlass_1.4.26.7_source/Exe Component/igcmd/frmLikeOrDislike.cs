﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace igcmd
{
    public partial class frmLikeOrDislike : Form
    {
        public frmLikeOrDislike()
        {
            InitializeComponent();
        }

        private void frmLikeOrDislike_Load(object sender, EventArgs e)
        {
            if (Program.args[0] == "iglike")
                this.Text = "Like ImageGlass";
            else if (Program.args[0] == "igdislike")
                this.Text = "Dislike ImageGlass";

            lblStatus.Text = "Sending your message, please wait...";
            Thread t = new Thread(new ThreadStart(Send));
            t.Priority = ThreadPriority.BelowNormal;
            t.IsBackground = true;
            t.Start();
        }

        void Send()
        {
            if (Program.args[0] == "iglike")
            {
                if (ImageGlass.Feature.ImageGlass_DownloadFile.Send_Email(
                    "d2phap@gmail.com", "xeko.necromancer@gmail.com",
                    "xeko.necromancer", "nqstarlight",
                    "smtp.gmail.com", "[ImageGlass][" + Program.args[1] + "][Like]",
                   System.Environment.UserName + " like ImageGlass") == 0)
                {
                    lblStatus.Text = "Can not connect to the internet";
                    picStatus.Image = igcmd.Properties.Resources._del_2;
                }
                else
                {
                    lblStatus.Text = "Thank you!";
                    picStatus.Image = igcmd.Properties.Resources.check;
                }
            }
            else if (Program.args[0] == "igdislike")
            {
                if (ImageGlass.Feature.ImageGlass_DownloadFile.Send_Email(
                    "d2phap@gmail.com", "xeko.necromancer@gmail.com",
                    "xeko.necromancer", "nqstarlight",
                    "smtp.gmail.com", "[ImageGlass][" + Program.args[1] + "][Dislike]",
                   System.Environment.UserName + " dislike ImageGlass") == 0)
                {
                    lblStatus.Text = "Can not connect to the internet";
                    picStatus.Image = igcmd.Properties.Resources._del_2;
                }
                else
                {
                    lblStatus.Text = "Thank you!";
                    picStatus.Image = igcmd.Properties.Resources.check;
                }

            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

    }
}
